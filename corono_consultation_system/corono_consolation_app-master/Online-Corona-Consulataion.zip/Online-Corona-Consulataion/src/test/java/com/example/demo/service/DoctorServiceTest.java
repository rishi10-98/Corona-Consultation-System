
package com.example.demo.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.List;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.example.demo.entity.Doctor;
import com.example.demo.entity.Gender;
import com.example.demo.repository.DoctorRepository;
import com.example.demo.repository.DoctorRepositoryTest;

import lombok.extern.slf4j.Slf4j;


@ExtendWith(SpringExtension.class)
@ExtendWith(MockitoExtension.class)
@Slf4j
public class DoctorServiceTest {

private static final Logger logger = LoggerFactory.getLogger(DoctorRepositoryTest.class);
	
	@MockBean
	private DoctorRepository doctorRepository;	
	
	@InjectMocks
	private DoctorService doctorService;
	
	
	@Test
	public void addDoctor() {
		Doctor doctor=new Doctor();
		
		doctor.setDocMail("abc@gmail.com");
		doctor.setDocName("abc");
		doctor.setDocPhone("8778887");
		doctor.setGender(Gender.Male);
		
		when(doctorRepository.save(doctor)).thenReturn(doctor);
		Doctor savedWardReport=doctorService.addDoctor(doctor);
		logger.info("Record of saved ward report : " + savedWardReport);
		assertEquals(doctor.getDocId(),savedWardReport.getDocId());
	}
	
	
	
	
	@Test
	public void testGetAllDoctor() {
		Doctor doctor1=new Doctor();		
		doctor1.setDocMail("abc@gmail.com");
		doctor1.setDocName("abc");
		doctor1.setDocPhone("8778887");
		doctor1.setGender(Gender.Male);
		
		Doctor doctor2=new Doctor();	
		doctor2.setDocMail("xyz@gmail.com");
		doctor2.setDocName("xyz");
		doctor2.setDocPhone("8778887");
		doctor2.setGender(Gender.Male);
		
		List<Doctor> allDoctor=List.of(doctor1, doctor2);
		when(doctorRepository.findAll()).thenReturn(allDoctor);
		List<Doctor> allSavedDoctor=doctorService.getAllDoctor();
		logger.info("Record of all saved ward report : " + allSavedDoctor);
		Assertions.assertThat(allSavedDoctor).isNotNull();
		Assertions.assertThat(allSavedDoctor.size()).isGreaterThan(0);
	}
	
	
	
	
}
