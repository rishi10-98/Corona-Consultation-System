package com.example.demo.repository;

import java.util.List;
import java.util.Optional;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.entity.Doctor;
import com.example.demo.entity.Gender;
import com.example.demo.entity.Patient;

@SpringBootTest
public class DoctorRepositoryTest {

	@Autowired
	private DoctorRepository doctorRepository;

	
	@Test
	public void testSaveDoctor() {						//testing method to add Doctor
		
	
		
		Doctor doctor=new Doctor();
				
		doctor.setDocMail("abc@gmail.com");
		doctor.setDocName("abc");
		doctor.setDocPhone("8778887");
		doctor.setGender(Gender.Male);
		
		Patient patient=new Patient();
		patient.setGender(Gender.Male);
		
		patient.setPatientAge(22);
		patient.setPatientName("xyz");
		patient.setPatientRoomnum(3);
		
		doctor.setPatients(List.of(patient));
		
			
		Doctor savedDoctor=doctorRepository.save(doctor);
		
		Assertions.assertThat(savedDoctor).isNotNull();
		
	}
	
	@Test
	public void testGetDoctorById() {						//testing method to get doctor by id
		
		Doctor doctor=new Doctor();
		
		
		Optional<Doctor> doc=doctorRepository.findById((long) 3);	
		 doctor =doc.get();
		 Long i= doctor.getDocId();
		 System.out.println(i);
		 Assertions.assertThat(i).isEqualTo(3);
		Assertions.assertThat(doc).isNotNull();
		
	}
	
	
	@Test
	public void testUpdateDoctor() {						//testing method to update employee by id
		Doctor doctor=new Doctor();		
		doctor.setDocMail("abc@gmail.com");
		doctor.setDocName("abc");
		doctor.setDocPhone("8778887");
		doctor.setGender(Gender.Male);
		
		doctorRepository.save(doctor);
		
		Optional<Doctor> updatedDoctor=doctorRepository.findById((long) 3);		
		Assertions.assertThat(updatedDoctor).isNotNull();
	}
	
	@Test
	public void testDeleteDoctor() {						//testing method to delete employee by giving id
		
		Doctor doctor=new Doctor();
		Optional<Doctor> updatedDoctor=doctorRepository.findById((long) 3);
		doctorRepository.deleteById((long) 3);
		
		
		doctor=updatedDoctor.get();
		Long i= doctor.getDocId();
		Assertions.assertThat(i).isNotNull();
	}
}
