package com.example.demo.service;
//
//import static org.junit.jupiter.api.Assertions.assertEquals;
//import static org.mockito.Mockito.when;
//
//import java.util.List;
//import java.util.Optional;
//
//import org.assertj.core.api.Assertions;
//import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.extension.ExtendWith;
//import org.mockito.InjectMocks;
//import org.mockito.junit.jupiter.MockitoExtension;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.boot.test.mock.mockito.MockBean;
//import org.springframework.test.context.junit.jupiter.SpringExtension;
//import com.example.demo.entity.WardReport;
//import lombok.extern.slf4j.Slf4j;
//@ExtendWith(SpringExtension.class)
//@ExtendWith(MockitoExtension.class)
//@Slf4j
//public class WardReportServiceTest {
//
//	private static final Logger logger = LoggerFactory.getLogger(WardReportServiceTest.class);
//	
//	@MockBean
//	private WardReportRepository wardReportRepository;	
//	
//	@InjectMocks
//	private WardReportService wardReportService;
//	
//	@Test
//	public void addWardReport() {
//		WardReport wardReport=new WardReport();
//		wardReport.setPatientId((long) 245643);
//		wardReport.setPatientName("Rishav");
//		wardReport.setWardNurseId((long) 546798);
//		wardReport.setWardNurse("Rashmika");
//		wardReport.setWardDoctorId((long) 955643);
//		wardReport.setWardDoctorName("C Roy");
//		when(wardReportRepository.save(wardReport)).thenReturn(wardReport);
//		WardReport savedWardReport=wardReportService.addWardReport(wardReport);
//		System.out.println("Record of saved ward report : " + savedWardReport);
//		assertEquals(wardReport.getReportId(),savedWardReport.getReportId());
//	}
//	@Test
//	public void testGetSAllWardReport() {
//		WardReport wardReport1=new WardReport();
//		wardReport1.setPatientId((long) 245643);
//		wardReport1.setPatientName("Rishav");
//		wardReport1.setWardNurseId((long) 546798);
//		wardReport1.setWardNurse("Rashmika");
//		wardReport1.setWardDoctorId((long) 955643);
//		wardReport1.setWardDoctorName("Dr. C Roy");
//		
//		WardReport wardReport2=new WardReport();
//		wardReport2.setPatientId((long) 244373);
//		wardReport2.setPatientName("Vinay");
//		wardReport2.setWardNurseId((long) 545898);
//		wardReport2.setWardNurse("Vaishnavi Rana");
//		wardReport2.setWardDoctorId((long) 945643);
//		wardReport2.setWardDoctorName("Dr. B.k Goyal");
//		
//		List<WardReport> allWardReport=List.of(wardReport1, wardReport2);
//		when(wardReportRepository.findAll()).thenReturn(allWardReport);
//		List<WardReport> allSavedWardReport=wardReportService.getWardReportList();
//		System.out.println("Record of all saved ward report : " + allSavedWardReport);
//		Assertions.assertThat(allSavedWardReport).isNotNull();
//		Assertions.assertThat(allSavedWardReport.size()).isGreaterThan(0);
//	}
//
//	@Test
//	public void testGetSingleWardReportById() {
//	
//		WardReport wardReport1=new WardReport();
//		wardReport1.setPatientId((long) 245643);
//		wardReport1.setPatientName("Rishav");
//		wardReport1.setWardNurseId((long) 546798);
//		wardReport1.setWardNurse("Rashmika");
//		wardReport1.setWardDoctorId((long) 955643);
//		wardReport1.setWardDoctorName("Dr. C Roy");
//		when(wardReportRepository.findById((long) 10)).thenReturn(Optional.of(wardReport1));
//	    Optional<WardReport> findReport=wardReportRepository.findById((long) 10);
//	    System.out.println(findReport.get());
//	    assertEquals(wardReport1.getPatientName(),findReport.get().getPatientName());
//	}
//}
