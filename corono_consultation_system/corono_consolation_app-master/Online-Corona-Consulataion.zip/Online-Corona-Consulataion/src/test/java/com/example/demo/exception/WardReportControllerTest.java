package com.example.demo.exception;

//import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
//import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
//
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.mockito.Mockito;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
//import org.springframework.boot.test.mock.mockito.MockBean;
//import org.springframework.test.web.servlet.MockMvc;
//import com.example.demo.controller.WardReportController;
//import com.example.demo.entity.WardReport;
//import com.example.demo.service.WardReportService;
//import org.springframework.http.MediaType;
//
//@WebMvcTest(WardReportController.class)
//public class WardReportControllerTest {
//	
//	@Autowired
//	private MockMvc mockMvc;
//	@MockBean
//	private WardReportService wardReportService;
//	
//	@Test
//    public void saveaddWardReport() throws Exception {
//		WardReport wardReport = new WardReport();
//		wardReport.setPatientId((long) 245643);
//		wardReport.setPatientName("Rishav");
//		wardReport.setWardNurseId((long) 546798);
//		wardReport.setWardNurse("Rashmika");
//		wardReport.setWardDoctorId((long) 955643);
//		wardReport.setWardDoctorName("C Roy");
//
//        Mockito.when(wardReportService.addWardReport(wardReport)).thenReturn(wardReport);
//        mockMvc.perform(post("/wardReport/add")
//        .contentType(MediaType.APPLICATION_JSON)
//        .content("{\n" +
//                "\t\"patientId\":\"245643\",\n" +
//                "\t\"patientName\":\"Rishav\",\n" +
//                "\t\"wardNurseId\":\"546798\"\n" +
//                "\t\"wardNurse\":\"Rashmika\",\n" +
//                "\t\"wardDoctorId\":\"955643\",\n" +
//                "\t\"wardDoctorName\":\"C Roy\"\n" +
//                "}"))
//                .andExpect(status().isOk());
//
//    }
//}
