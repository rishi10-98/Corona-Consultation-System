package com.example.demo.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;
import java.util.List;
import java.util.Optional;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.example.demo.entity.Ward;
import com.example.demo.entity.WardReport;
import com.example.demo.repository.WardRepository;
import com.example.demo.repository.WardRepositoryTest;

import lombok.extern.slf4j.Slf4j;

@ExtendWith(SpringExtension.class)
@ExtendWith(MockitoExtension.class)
@Slf4j
public class WardServiceTest {


	private static final Logger logger = LoggerFactory.getLogger(WardServiceTest.class);
	
	@MockBean
	private WardRepository wardRepository;	
	
	@InjectMocks
	private WardService wardService;
	
	@Test
	public void addWard() {
		Ward ward=new Ward();
		ward.setWardId(5);
		when(wardRepository.save(ward)).thenReturn(ward);
		Ward savedWard=wardService.addWard(ward);
		System.out.println("Record of saved ward : " + savedWard);
		assertEquals(ward.getWardId(),savedWard.getWardId());
	}
	
	@Test
	public void testGetSAllWard() {
		
		Ward ward1=new Ward();
		ward1.setWardId(5);

		Ward ward2=new Ward();
		ward2.setWardId(7);
		
		List<Ward> allWard=List.of(ward1, ward2);
		when(wardRepository.findAll()).thenReturn(allWard);
		List<Ward> allSavedWard=wardService.getWardList();
		System.out.println("Record of all saved ward  : " + allSavedWard);
		Assertions.assertThat(allSavedWard).isNotNull();
		Assertions.assertThat(allSavedWard.size()).isGreaterThan(0);
	}

	@Test
	public void testGetSingleWardReportById() {
	
		Ward ward=new Ward();
		ward.setWardId(7);
		when(wardRepository.findById(3)).thenReturn(Optional.of(ward));
	    Optional<Ward> find=wardRepository.findById(3);
	    System.out.println(find.get());
	    assertEquals(ward.getWardId(),find.get().getWardId());
	}
}
