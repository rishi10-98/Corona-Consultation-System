package com.example.demo.repository;
//
//import org.assertj.core.api.Assertions;
//import org.junit.jupiter.api.Order;
//import org.junit.jupiter.api.Test;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
//import com.example.demo.entity.WardReport;
//import java.util.List;
//import java.util.Optional;
//import lombok.extern.slf4j.Slf4j;
//
//@SpringBootTest
//@Slf4j
//public class WardReportRepositoryTest {
//
//	private static final Logger logger = LoggerFactory.getLogger(WardReportRepositoryTest.class);
//	
//	
//		@Autowired
//		private WardReportRepository wardReportRepository;			
//		@Test
//		@Order(1)
//		public void testSaveWardReport() {
//			
//			WardReport wardReports=new WardReport();
//			wardReports.setPatientId((long) 245643);
//			wardReports.setPatientName("Rishav");
//			wardReports.setWardNurseId((long) 546798);
//			wardReports.setWardNurse("Rashmika");
//			wardReports.setWardDoctorId((long) 955643);
//			wardReports.setWardDoctorName("C Roy");
//			WardReport savedWardReport=wardReportRepository.save(wardReports);
//			logger.info("Record of saved ward report : " + savedWardReport);
//			Assertions.assertThat(savedWardReport).isNotNull();
//			
//		}	
//		@Test
//		@Order(3)
//		public void testGetSingleWardReportById() {
//			
//			Optional<WardReport> wr=wardReportRepository.findById((long) 10);		
//		    WardReport wardReport=wr.get();
//		    logger.info("Record of ward report with Id : " + wardReport);
//		    Assertions.assertThat(wr).isNotNull();
//			
//		}
//
//		@Test
//		@Order(2)
//		public void testGetSAllWardReport() {
//			List<WardReport> allWardReports=wardReportRepository.findAll();
//			logger.info("All ward reports : " + allWardReports); 
//			Assertions.assertThat(allWardReports).isNotNull();
//			
//		}
//		
//		@Test
//		@Order(4)
//		public void testDeleteWardReport() {
//			WardReport wardReports=new WardReport();
//			wardReportRepository.deleteById((long) 10);
//			logger.info("Record of ward report deleted successfully"); 
//			
//		}	
//
//}
