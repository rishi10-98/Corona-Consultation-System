package com.example.demo.repository;

import java.util.Optional;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.entity.Employee;

@SpringBootTest
public class EmployeeRepositoryTest {
	
	@Autowired
	private IEmployeeRepository employeeRepository;			//employee repository object
	
	@Test
	public void testGetAllEmployees() {						//testing method to get all the employees
		Employee employee=new Employee();
		
		Employee allEmployees=employeeRepository.save(employee);
		
		Assertions.assertThat(allEmployees).isNotNull();
	}
	
	@Test
	public void testSaveEmployee() {						//testing method to add employee
		
		Employee employee=new Employee();
		employee.setEmployeeName("Shashank");
		employee.setEmployeeName("Doctor");
		employee.setEmployeeSalary(20000.00);
		
			
		Employee savedEmployeee=employeeRepository.save(employee);
		
		Assertions.assertThat(savedEmployeee).isNotNull();
		
	}
	
	@Test
	public void testGetEmployeeById() {						//testing method to get employee by id
		
		Employee employee=new Employee();
		employee.setEmployeeName("Shashank");
		employee.setEmployeeName("Doctor");
		employee.setEmployeeSalary(20000.00);
		
		employeeRepository.save(employee);
		
		Optional<Employee> emp=employeeRepository.findById((long) 3);		
		Assertions.assertThat(emp).isNotNull();
		
	}
	
	@Test
	public void testUpdateEmployee() {						//testing method to update employee by id
		Employee employee=new Employee();
		employee.setEmployeeId((long)3);
		employee.setEmployeeName("Shashank");
		employee.setEmployeeName("Doctor");
		employee.setEmployeeSalary(20000.00);
		
		employeeRepository.save(employee);
		
		Optional<Employee> updatedEmployee=employeeRepository.findById((long) 3);		
		Assertions.assertThat(updatedEmployee).isNotNull();
	}
	
	@Test
	public void testDeleteEmployee() {						//testing method to delete employee by giving id
		
		Employee employee=new Employee();
		employee.setEmployeeName("Shashank");
		employee.setEmployeeName("Doctor");
		employee.setEmployeeSalary(20000.00);
		
		employeeRepository.save(employee);
		
			
		employeeRepository.deleteById((long)3);
		
	}

}