package com.example.demo.repository;

import java.util.List;
import java.util.Optional;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import com.example.demo.entity.Ward;
import lombok.extern.slf4j.Slf4j;

@SpringBootTest
@Slf4j
public class WardRepositoryTest {
	
	private static final Logger logger = LoggerFactory.getLogger(WardRepositoryTest.class);

	
//	@Autowired
//	private WardRepository wardRepository;
//	
//	@Test
//	@Order(1)
//	public void saveWard() {
//		
//		Ward ward=new Ward();
//		ward.setWardNumber(4);
//		ward.setWardCapacity(10);
//		ward.setAvailableBed(1);
//		ward.setWardFee((float) 10000.00);
//		Ward savedWard=wardRepository.save(ward);
//		logger.info("Record of ward is saved in database successfully");
//		Assertions.assertThat(savedWard).isNotNull();
//	}
//
//	@Test
//	@Order(3)
//	public void testGetSingleWardById() {
//		
//		Optional<Ward> getWard=wardRepository.findById(3);		
//	    Ward ward=getWard.get();
//	    logger.info("Record of ward with Id : " + ward);
//	    Assertions.assertThat(getWard).isNotNull();
//		
//	}
//
//	@Test
//	@Order(2)
//	public void testGetSAllWardReport() {
//		List<Ward> allWard=wardRepository.findAll();
//		logger.info("All ward :" + allWard); 
//		Assertions.assertThat(allWard).isNotNull();
//		
//	}
//	
//	@Test
//	@Order(4)
//	public void testDeleteWard() {
//		Ward ward=new Ward();
//		wardRepository.deleteById(3);
//		logger.info("Record of ward deleted successfully"); 
//		
//	}	

}
