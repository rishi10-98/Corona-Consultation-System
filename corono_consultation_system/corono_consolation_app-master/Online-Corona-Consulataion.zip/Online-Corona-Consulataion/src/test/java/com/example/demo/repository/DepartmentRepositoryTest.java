package com.example.demo.repository;
import java.util.Optional;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import com.example.demo.entity.Department;
@SpringBootTest
public class DepartmentRepositoryTest {
	
	@Autowired
	private IDepartmentdao departmentdao;			//department repository object
	
	@Test
	public void testaddDepartment() {						//testing method to add department
		
		Department department=new Department();
		department.setDepatmentId((long) 3);
		department.setDepartmentName("asdas");
		
			
		Department addDepartment=departmentdao.save(department);
		
		Assertions.assertThat(addDepartment).isNotNull();
		
	}
	
	@Test
	public void testgetDepartmentById() {						//testing method to get department by id
		
		Department department=new Department();
		department.setDepatmentId((long) 3);
		department.setDepartmentName("asdas");
		
		departmentdao.save(department);
		
		Optional<Department> department1=departmentdao.findById((long) 1);		
		Assertions.assertThat(department1).isNotNull();
		
	}
	
	@Test
	public void testUpdateEmployee() {						//testing method to update department by id
		Department department=new Department();
		department.setDepatmentId((long) 3);
		department.setDepartmentName("asdas");
		
		departmentdao.save(department);
		
		Optional<Department> updatedDepartment=departmentdao.findById((long) 3);		
		Assertions.assertThat(updatedDepartment).isNotNull();
	}
	
	@Test
	public void testDeleteDepartment() {						//testing method to delete department by giving id
		
		Department department=new Department();
		department.setDepatmentId((long) 12);
		department.setDepartmentName("asdas");
		departmentdao.save(department);			
		departmentdao.deleteById((long) 12);
		
	}

}