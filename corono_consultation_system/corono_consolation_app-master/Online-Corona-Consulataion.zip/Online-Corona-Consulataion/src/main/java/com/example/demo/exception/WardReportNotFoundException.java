package com.example.demo.exception;
//
//public class WardReportNotFoundException extends RuntimeException{
//	private static final long serialVersionUID = 1L;
//}
