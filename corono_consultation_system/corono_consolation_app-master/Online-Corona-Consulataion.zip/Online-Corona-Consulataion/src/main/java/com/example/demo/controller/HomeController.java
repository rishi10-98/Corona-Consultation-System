//package com.example.demo.controller;
//
//
//import com.example.demo.entity.UserRegistration;
//import com.example.demo.jwt.JwtUtil;
//import com.example.demo.service.IUserRegistrationService;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.security.authentication.AuthenticationManager;
//import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
//import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
//
//import org.springframework.ui.Model;
//import org.springframework.web.bind.annotation.*;
//
//@RestController
////@RequestMapping("/register")
//public class HomeController {
//
//    @Autowired
//    private IUserRegistrationService uservice;
//
//    @Autowired
//    private JwtUtil jwtUtil;
//
//    @Autowired
//    private AuthenticationManager authenticationManager;
//
//    @GetMapping(value = "/")
//    public String homePage()
//    {
//        return "home";
//    }
//    @GetMapping(value = "/about")
//    public String aboutPage()
//    {
//        return "about";
//    }
//
//    @GetMapping(value = "/admissions")
//    public String admissionsPage()
//    {
//        return "admissions";
//    }
//
//
//
//    @PostMapping(value = "/login")
//    public ResponseEntity<UserResponse> loginPage(@RequestBody UserRequest request)
//    {
//        authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(request.getUsername(),request.getPassword()));
//        String token=jwtUtil.generateToken(request.getUsername());
//        UserResponse userResponse=new UserResponse(token);
//        return new ResponseEntity<UserResponse>(userResponse,HttpStatus.OK);
//    }
//
//    @GetMapping(value = "/register")
//    public String getUserRegistrationPage()
//    {
//        return "register";
//    }
//
//    /*
//	 * 
//	 * { 
//	 * "fname":"Akhil", "lname":"Sakharwade", 
//	 * "email":"asakharwade2@gmail.com",
//	 * "password":"Akhil@123",
//	 *  "username":"Akhil111", "roles":["CUSTOMER"],
//	 *  "gender":"MALE",
//	 *  "address":{ "city":"Mumbai", "state":"Maharashtra" 
//	 *   }
//	 *  }
//	 */
//    @PostMapping(value = "/register")
//    public String postUserRegistrationPage(@RequestBody UserRegistration user, Model model)
//    {
//        UserRegistration userRegistration=uservice.saveUser(user);
//        model.addAttribute("msg","Registration Success!");
//        return "register";
//    }
//
//
//}
