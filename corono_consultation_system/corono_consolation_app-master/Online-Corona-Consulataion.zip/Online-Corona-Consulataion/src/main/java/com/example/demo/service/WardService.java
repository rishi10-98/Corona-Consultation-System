package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.repository.WardRepository;
import com.example.demo.entity.Doctor;
import com.example.demo.entity.Ward;
import com.example.demo.exception.MyWardException;

@Service
public class WardService implements IWardService {

	private static final Logger logger = LoggerFactory.getLogger(WardService.class);
	
	
	@Autowired
	private WardRepository wardRepository;

	@Override
	public Ward addWard(Ward ward) throws MyWardException {
		logger.info("Add Ward report in service layer "+ ward);
		return wardRepository.save(ward);
	}

	@Override
	public List<Ward> getWardList() throws MyWardException {
		logger.info("Fetch all Ward Report in service layer ");
		return wardRepository.findAll();
	}

	@Override
	public Optional<Ward> getWardById(Integer wardId) throws MyWardException {
		logger.info("Trying to fetch User in service layer ");
		return wardRepository.findById(wardId);
	}

	@Override
	public void deleteWard(Integer wardId) throws MyWardException {
		logger.info("Delete Ward Report in service layer ");
		wardRepository.deleteById(wardId);
	}

	@Override
	public Ward updateWard(Ward ward, Integer wardId) throws MyWardException {
		logger.info("Trying to update Ward Report in service layer ");
		Optional<Ward> wardFound = getWardById(wardId);	
		Ward exWard=wardRepository.getOne(wardId);
		BeanUtils.copyProperties(ward, exWard, "wardId");
			return wardRepository.save(exWard);
	}

}