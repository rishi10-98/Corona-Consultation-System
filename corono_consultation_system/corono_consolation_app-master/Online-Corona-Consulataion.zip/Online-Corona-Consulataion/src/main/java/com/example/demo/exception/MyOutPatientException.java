package com.example.demo.exception;

public class MyOutPatientException extends Exception{
	
	private static final long serialVersionUID = 1L;

	public MyOutPatientException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public MyOutPatientException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
