package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import com.example.demo.entity.Room;
import com.example.demo.exception.MyRoomException;

public interface IRoomService {

	public Room addRoom(Room room) throws MyRoomException;

	public List<Room> getRoomList() throws MyRoomException;

	public Optional<Room> getRoomById(Long roomId) throws MyRoomException;

	public void deleteRoom(Long roomId) throws MyRoomException;

	public Room updateRoom(Room room) throws MyRoomException;
}
