package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import com.example.demo.entity.InPatient;
import com.example.demo.exception.MyInPatientException;

public interface IInPatientService {
	
	public InPatient addInPatientById(Integer pId);

}
