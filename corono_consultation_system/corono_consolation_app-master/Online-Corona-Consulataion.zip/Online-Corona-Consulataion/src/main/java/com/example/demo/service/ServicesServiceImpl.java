package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Services;
import com.example.demo.exception.ServicesNotFoundException;
import com.example.demo.repository.ServicesRepository;

//import lombok.var;
@Service
public class ServicesServiceImpl implements IServicesService {
	@Autowired
	private ServicesRepository srepo;
	@Override
	public Services saveServices(Services service1) {
		Services s=srepo.save(service1);
		System.out.println(s);
		return s;

	}
	@Override
	public Services getService(Integer serviceId) {
		return srepo.findById(serviceId).orElseThrow(
				()->new ServicesNotFoundException("Services With Given ID :"+serviceId+" Not Available"));
				
	}
	@Override
	public void deleteService(Integer serviceId) {
		srepo.deleteById(serviceId);
		 // return s = srepo.removeIf(post -> post.getId().equals(serviceId));
	}
	@Override
	public Services updateService(Integer serviceId, Services service) {
		//>>>ServicesServiceImpl s2=new ServicesServiceImpl();
		// TODO Auto-generated method stub
		Services serviceFound = srepo.findById(serviceId)
				
						.orElseThrow(()->new ServicesNotFoundException("Services With Given ID :"+serviceId+" Not Available"));
		//Services serviceId1;
		if (service.getAmbulanceStatus() != null)
		
			serviceFound.setAmbulanceStatus(service.getAmbulanceStatus());
	    
		//else
	//	{
		
			//s2.saveServices(Services s3 );
	//	}
		
		if (service.getEmergencyCare() != null)
			serviceFound.setEmergencyCare(service.getEmergencyCare());
		if (service.getVentilatorsNo() != null)
			serviceFound.setVentilatorsNo(service.getVentilatorsNo());
		/*
	
		
		*/
		//final Services updatedServices = ServicesRepository.save(service1);
		 //return ResponseEntity.ok(updatedServices);
		return srepo.save(serviceFound);
	}
	
}
