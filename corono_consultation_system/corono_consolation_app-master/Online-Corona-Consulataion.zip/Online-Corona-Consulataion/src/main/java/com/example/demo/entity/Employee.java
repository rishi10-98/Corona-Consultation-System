package com.example.demo.entity;
import java.util.List;

import java.io.Serializable;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.CascadeType;
import javax.persistence.FetchType;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.NotEmpty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;


@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name="EMPLOYEE")
public class Employee implements Serializable {
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long employeeId;
	
	@Column(name="NAME")
	@NotEmpty(message = "Please provide Name")
	private String employeeName;
	
	@Column(name="ROLE")
	@NotEmpty(message = "Please provide Role")
	private String employeeRole;
	
	@Column(name="SALARY")
	//@NotEmpty(message = "Please provide Salary")
	@DecimalMin(value = "1000.00" , message = "Value should be greater than 10000.00")
	@DecimalMax(value = "100000.00" , message = "Value should be less than 100000.00")
	private Double employeeSalary;

	@Embedded
	@AttributeOverrides({
		  @AttributeOverride( name = "employeeCity", column = @Column(name = "employee_city")),
		  @AttributeOverride( name = "employeeDistict", column = @Column(name = "employee_distict")),
		  @AttributeOverride( name = "employeeState", column = @Column(name = "employee_state"))
		})
	private Address address;
	
	
	  @ManyToOne(cascade = CascadeType.ALL )
	  @JoinColumn(name="DEPARTMENT_ID")
	  Department departments;
}
	
