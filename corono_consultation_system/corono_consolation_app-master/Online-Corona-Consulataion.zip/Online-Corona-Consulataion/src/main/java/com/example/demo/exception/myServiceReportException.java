package com.example.demo.exception;

public class myServiceReportException extends RuntimeException{
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public myServiceReportException() {
		super();
		
	}

	public myServiceReportException(String message) {
		super(message);
		
	}
}
