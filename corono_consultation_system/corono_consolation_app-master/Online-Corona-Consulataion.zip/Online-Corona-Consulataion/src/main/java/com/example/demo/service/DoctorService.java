package com.example.demo.service;

import java.util.List;
import java.util.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Doctor;
import com.example.demo.entity.DoctorReport;
import com.example.demo.exception.DoctorNotFoundException;
import com.example.demo.exception.myDoctorException;
import com.example.demo.exception.myDoctorReportException;
import com.example.demo.repository.DoctorRepository;
//Doctor Service layer
@Service
public class DoctorService implements IDoctorService {
	
	private static final Logger logger = LoggerFactory.getLogger(DoctorService.class);
	
	@Autowired
	private DoctorRepository doctorRepository;

	// Adding doctor object at service layer
	@Override
	public Doctor addDoctor(Doctor doctor) throws myDoctorException {
		// TODO Auto-generated method stub
		logger.info("Adding Doctor in service layer");
		return doctorRepository.save(doctor);
	}
		
	
	
// Getting all doctor in service layer
	@Override
	public List<Doctor> getAllDoctor() throws myDoctorException {
		// TODO Auto-generated method stub
		logger.info("getting all doctor info in service layer");
		return doctorRepository.findAll();
	}
//get single doctor
	@Override
	public Optional<Doctor> getDoctorWithId(Long docId) throws myDoctorException {
		// TODO Auto-generated method stub
		logger.info("get single doctor with that perticular id");
		return Optional.of(doctorRepository.findById(docId).orElseThrow(()->new DoctorNotFoundException("Doctor with given id "+docId+" not Available")));
		
	}

	@Override
	public Doctor getDoctorupdate(Doctor doctor, Long docId) throws myDoctorException {
		// TODO Auto-generated method stub
		logger.info("updating doctor in service layer");
		logger.info("Doctor in service"+doctor);
		//Integer docId = doctor.getDocId();
		logger.info("got id="+docId);
		Optional<Doctor> docFound = getDoctorWithId(docId);	
		Doctor exDoctor=doctorRepository.getOne(docId);
		BeanUtils.copyProperties(doctor, exDoctor, "docId");
			return doctorRepository.save(exDoctor);
		
	
	}

	@Override
	public void deleteDoctor(Long docId) throws myDoctorException {
		// TODO Auto-generated method stub
		logger.info("deleting doctor from table");
		doctorRepository.deleteById(docId);
	}



	@Override
	public DoctorReport addDoctorReport(DoctorReport doctorReport) throws myDoctorReportException {
		// TODO Auto-generated method stub
		return null;
	}



	@Override
	public List<Doctor> getDoctorByName(String name) throws myDoctorException {
		// TODO Auto-generated method stub
		List<Doctor> doctor =doctorRepository.findByDepartmentName(name);
		return doctor;
	}

}
