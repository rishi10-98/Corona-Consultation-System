package com.example.demo.exception;

public class MyDepartmentException extends Exception {
	private static final long serialVersionUID = 1L;

	public MyDepartmentException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public MyDepartmentException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
