package com.example.demo.exception;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;


public class WardExceptionController {

	 @ExceptionHandler(value = WardNotFoundException.class)
	   public ResponseEntity<Object> exception(WardNotFoundException exception) {
	      return new ResponseEntity<>("Ward not found", HttpStatus.NOT_FOUND);
	   }
	   @ExceptionHandler(value = MyWardException.class)
	   public ResponseEntity<Object> exception(MyWardException exception) {
	      return new ResponseEntity<>("User Bad request", HttpStatus.BAD_REQUEST);
	   }
	
}
