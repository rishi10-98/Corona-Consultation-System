package com.example.demo.service;
import java.util.List;
import java.util.Optional;

import org.springframework.transaction.annotation.Transactional;

import com.example.demo.repository.IEmployeeRepository;
import com.example.demo.entity.Doctor;
import com.example.demo.entity.Employee;
import com.example.demo.exception.MyEmployeeException;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

//Annotation service component
@Service
public class EmployeeService implements IEmployeeService {
	private static final Logger logger = LoggerFactory.getLogger(EmployeeService.class);

	//Injecting repository object
	@Autowired
	private IEmployeeRepository employeeRepository;
	
	@Override
	public Optional<Employee> getSingleEmployee(Long id) throws MyEmployeeException {
		logger.info("Trying to fetch User in service layer ");
		return employeeRepository.findById(id);
	}
	
	@Override
	@Transactional //DML
	public Employee saveEmployee(Employee employee) throws MyEmployeeException {
		logger.info("Trying to add User in service layer "+ employee);
		return employeeRepository.save(employee);
	}
	
	@Override
	@Transactional //DML
	public Employee updateEmployee(Employee employee, Long id) throws MyEmployeeException {
		logger.info("Trying to update User in service layer ");
		Optional<Employee> patientFound = getSingleEmployee(id);	
		Employee exEmployee=employeeRepository.getOne(id);
		BeanUtils.copyProperties(employee, exEmployee, "employeeId");
			return employeeRepository.save(exEmployee);
	}
	 
	
	@Override
	@Transactional //DML
	public void deleteEmployee(Long id) throws MyEmployeeException {
		logger.info("Trying to delete User in service layer ");
		employeeRepository.deleteById(id);
	}

	@Override
	public List<Employee> getAllEmployees() throws MyEmployeeException {
		logger.info("Trying to fetch all User in service layer ");
		// TODO Auto-generated method stub
		return employeeRepository.findAll();
	}
}

