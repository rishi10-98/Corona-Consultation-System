package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

//import com.example.demo.controller.PatientController;
import com.example.demo.repository.IPatientRepository;
import com.example.demo.entity.Doctor;
import com.example.demo.entity.Patient;
import com.example.demo.exception.MyPatientException;

//@SuppressWarnings("unused")
@Service("patientService")
public class PatientService implements IPatientService {
	private static final Logger logger = LoggerFactory.getLogger(PatientService.class);
	@Autowired
	private IPatientRepository patientRepository;

	@Override
	public Optional<Patient> getPatientById(Integer patientId) throws MyPatientException {
		logger.info("Trying to fetch Patient in service layer ");

		return patientRepository.findById(patientId);
	}

	@Override
	@Transactional 
	public Patient addPatient(Patient patient) throws MyPatientException {
		logger.info("Trying to add patient in service layer "+ patient);
		
		// TODO Auto-generated method stub
		return patientRepository.save(patient);
	}

	@Override
	@Transactional 
	public Patient updatePatient(Patient patient, Integer patientId) throws MyPatientException {
		logger.info("Trying to update patient in service layer ");
		
		// TODO Auto-generated method stub
		Optional<Patient> patientFound = getPatientById(patientId);	
		Patient expatient=patientRepository.getOne(patientId);
		BeanUtils.copyProperties(patient, expatient, "patientId");
			return patientRepository.save(expatient);
	}

	@Override
	@Transactional 
	public void deletePatient(Integer patientId) throws MyPatientException {
		logger.info("Trying to delete Patient in service layer ");
		 patientRepository.deleteById(patientId);
	}

	@Override
	public List<Patient> getPatientList() throws MyPatientException {
		logger.info("Trying to fetch all User in service layer ");
		// TODO Auto-generated method stub
		return patientRepository.findAll();
	}


		// TODO Auto-generated method stub
		
}
