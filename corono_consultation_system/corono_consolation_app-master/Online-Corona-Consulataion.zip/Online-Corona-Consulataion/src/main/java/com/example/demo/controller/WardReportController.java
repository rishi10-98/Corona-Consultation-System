package com.example.demo.controller;
//import java.util.ArrayList;
//import java.util.List;
//import java.util.Optional;
//
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.CrossOrigin;
//import org.springframework.web.bind.annotation.DeleteMapping;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.PutMapping;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.ResponseBody;
//import org.springframework.web.bind.annotation.RestController;
//import com.example.demo.entity.WardReport;
//import com.example.demo.exception.WardReportNotFoundException;
//import com.example.demo.service.IWardReportService;
//import com.example.demo.service.WardReportService;
//
//@RestController
//@RequestMapping(value="/wardReport")
//public class WardReportController {
//
//	private static final Logger logger = LoggerFactory.getLogger(WardReportController.class);
//	@Autowired
//	private IWardReportService wardReportService;
//	/*
//	 * http://localhost:8080/wardReport/add
//	 * This particular url is response for adding ward report
//	 * HTTP Method post is required
//	 */
//	@PostMapping(path = "/add")
//	public ResponseEntity<WardReport> addWardReport(@RequestBody WardReport wardReport) throws WardReportNotFoundException {
//		try {
//			logger.info("Trying to add Record  : " + wardReport);
//			WardReport addedWardReport = wardReportService.addWardReport(wardReport);
//			return new ResponseEntity<>(wardReport, HttpStatus.CREATED);//201
//		} catch (Exception e) {
//			logger.error("Record NOT Added  : " +wardReport);
//			return new ResponseEntity<>(null, HttpStatus.EXPECTATION_FAILED);	
//		}
//	}
//	/*
//	 * http://localhost:8080/wardReport/getAll
//	 * This particular url is response for getting all ward report
//	 * HTTP Method get is required
//	 */
//		@GetMapping(path = "/getAll", produces = "application/json")
//		public ResponseEntity<List<WardReport>> getAllWardReport() throws WardReportNotFoundException {
//			logger.info("Trying to fetch Ward Report list ");
//			try {
//				List<WardReport> wardReports = wardReportService.getWardReportList();
//				if (wardReports.isEmpty()) {
//					return new ResponseEntity<>(HttpStatus.NO_CONTENT);
//				}
//				return new ResponseEntity<>(wardReports, HttpStatus.OK);
//			} catch (Exception e) {
//				logger.error("Record NOT found : ");
//				return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
//			}
//		}
//		/*
//		 * http://localhost:8080/wardReport/
//		 * This particular url is response for getting single ward report
//		 * HTTP Method get is required
//		 */
//		@GetMapping(path = "/singleRecord{reportId}", produces = "application/json")
//		public ResponseEntity<WardReport> getWardReportById(@PathVariable Long reportId) throws WardReportNotFoundException {
//			Optional<WardReport> wardReport = null;
//			logger.info("Trying to search Record with Id : " + reportId);
//			try {
//				wardReport = wardReportService.getWardReportById(reportId);
//
//				if (wardReport.isPresent()) {
//					return new ResponseEntity<>(wardReport.get(), HttpStatus.OK);
//				} else {
//					return new ResponseEntity<>(HttpStatus.NOT_FOUND);
//				}
//			} catch (Exception e) {
//				logger.error("Record NOT Found with Id : " + reportId);
//				return new ResponseEntity<WardReport>(new WardReport(), HttpStatus.EXPECTATION_FAILED);
//			}
//		}
//
//		/*
//		 * http://localhost:8080/wardReport/getAll
//		 * This particular url is response for deleting ward report
//		 * HTTP Method get is required
//		 */
//		@DeleteMapping(path="/delete/{reportId}")
//		public ResponseEntity<String> deleteWardReport(@PathVariable Long reportId) throws WardReportNotFoundException {
//			
//			try {
//				wardReportService.deleteWardReport(reportId);
//				Optional<WardReport> delWardReport = wardReportService.getWardReportById(reportId);
//				logger.info("Record Deleted with Id : " + reportId);
//				return new ResponseEntity<>("Record Deleted...with id : "+reportId,HttpStatus.OK);
//			} catch (Exception e) {
//				logger.error("Record NOT Deleted with Id : " + reportId);
//				return new ResponseEntity<>("Record not found with id : "+reportId,HttpStatus.EXPECTATION_FAILED);
//			}
//		}
//
//		@PutMapping("/{id}")
//		public ResponseEntity<Object> updateWardReport(@RequestBody WardReport wardReport, @PathVariable Long id)
//				throws WardReportNotFoundException {
//			logger.info("trying to update user : " + wardReport);
//			try {
//				Optional<WardReport> wardReportFound = wardReportService.getWardReportById(id);
//
//				if (wardReportFound.isPresent()) {
//					wardReportService.updateWardReport(wardReport);
//					System.out.println("Record Updated : " + wardReport);
//					return ResponseEntity.ok(wardReport);
//				} else {
//					return new ResponseEntity<>("Record NOT updated with Id : " + wardReport,HttpStatus.NO_CONTENT);
//				}
//			} catch (Exception e) {
//				logger.error("Record NOT updated with Id : " + wardReport);
//				return new ResponseEntity<>("Record NOT updated with Id : " + wardReport, HttpStatus.EXPECTATION_FAILED);
//			}
//
//		}
//
//		
//		
//		
//}
