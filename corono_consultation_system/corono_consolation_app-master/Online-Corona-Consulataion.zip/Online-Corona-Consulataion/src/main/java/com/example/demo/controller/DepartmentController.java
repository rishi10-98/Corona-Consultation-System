package com.example.demo.controller;
import java.util.List;
import java.util.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.example.demo.entity.Department;
import com.example.demo.exception.DepartmentNotFoundException;
import com.example.demo.service.IDepartmentService;

@RestController
@RequestMapping(value = "/department")
public class DepartmentController {
	private static final Logger logger = LoggerFactory.getLogger(DepartmentController.class);
	@Autowired
	private IDepartmentService departmentService;
	
	/* 
	 * http://localhost:8080/department/departments
	 * this method get all the department object
	 * Http Post method Required
	 * */
	
	@CrossOrigin("*")
	@GetMapping(path = "/departments")
	public ResponseEntity<List<Department>> getAllDepartments() throws DepartmentNotFoundException {
		logger.info("Trying to fetch Department list ");
		try {
			List<Department> departments = departmentService.getDepartmentList();

			if (departments.isEmpty()) {
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			}
			return new ResponseEntity<>(departments, HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Record NOT found : ");
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	
	/* 
	 * http://localhost:8080//department/id
	 * this method get single department by id
	 * Http Post method Required
	 * */

	
	@GetMapping(path = "/{id}")
	// value passed along with url ,variable passed along with path
	public ResponseEntity<Department> getDepartmentById(@PathVariable Long id) throws DepartmentNotFoundException {
		Optional<Department> department = null;
		logger.info("Trying to search Record with Id : " + id);
		try {
			department = departmentService.getDepartmentById(id);

			if (department.isPresent()) {
				return new ResponseEntity<>(department.get(), HttpStatus.OK);
			} else {
				return new ResponseEntity<>(HttpStatus.NOT_FOUND);
			}
		} catch (Exception e) {
			logger.error("Record NOT Found with Id : " + id);
			return new ResponseEntity<Department>(HttpStatus.EXPECTATION_FAILED);
		}
	}
	
	
	/* 
	 * http://localhost:8080//department/addDepartment
	 * this method get add department to the table
	 * Http Post method Required
	 * */

	
	@PostMapping(path = "/addDepartment")
	public ResponseEntity<Department> addDepartment(@RequestBody Department department) throws DepartmentNotFoundException {
		try {
			logger.info("Trying to add Record  : " + department);
			Department addedDepartment = departmentService.addDepartment(department);
			return new ResponseEntity<>(department, HttpStatus.CREATED);//201
		} catch (Exception e) {
			logger.error("Record NOT Added  : " + department);
			return new ResponseEntity<>(department, HttpStatus.EXPECTATION_FAILED);
			
		}
	}
	
	
	/* 
	 * http://localhost:8080//department/id
	 * this method get delete single department by id
	 * Http Post method Required
	 * */

	
	@DeleteMapping("/{depatmentId}")
	public ResponseEntity<String> deleteDepartment(@PathVariable Long depatmentId) throws DepartmentNotFoundException {
		
		try {
			departmentService.deleteDepartment(depatmentId);
			
			logger.info("Record Deleted with Id : " + depatmentId);
			return new ResponseEntity<>("Record Deleted...with id : "+depatmentId,HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Record NOT Deleted with Id : " + depatmentId);
			return new ResponseEntity<>("Record not found with id : "+depatmentId,HttpStatus.EXPECTATION_FAILED);
		}
	}

	
	/* 
	 * http://localhost:8080//department/id
	 * this method update single department by id
	 * Http Post method Required
	 * */

	
	@PutMapping("/{id}")
	public ResponseEntity<Object> updateDepartment(@RequestBody Department department, @PathVariable Long id)
			throws DepartmentNotFoundException {
		logger.info("trying to update user : " + department);
		try {
			Optional<Department> departmentFound = departmentService.getDepartmentById(id);

			if (departmentFound.isPresent()) {
				departmentService.updateDepartment(department, id);
				System.out.println("Record Updated : " + department);
				return ResponseEntity.ok(department);
			} else {
				return new ResponseEntity<>("Record NOT updated with Id : " + department,HttpStatus.NO_CONTENT);
			}
		} catch (Exception e) {
			logger.error("Record NOT updated with Id : " + department);
			return new ResponseEntity<>("Record NOT updated with Id : " + department, HttpStatus.EXPECTATION_FAILED);
		}

	}

}