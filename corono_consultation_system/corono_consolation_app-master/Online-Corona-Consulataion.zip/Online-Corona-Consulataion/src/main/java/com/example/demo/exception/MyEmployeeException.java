package com.example.demo.exception;

public class MyEmployeeException extends Exception {
	private static final long serialVersionUID = 1L;

	public MyEmployeeException() {
		super();
	}
	
	public MyEmployeeException(String message)
	{
		super(message);
	}

}
