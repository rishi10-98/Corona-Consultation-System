package com.example.demo.exception;

public class myDoctorReportException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	public myDoctorReportException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public myDoctorReportException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
