package com.example.demo.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Patient;
import com.example.demo.exception.MedicineNotFoundException;
import com.example.demo.exception.PatientException;
import com.example.demo.exception.PatientNotFoundException;
import com.example.demo.service.IBillingService;
import com.example.demo.service.IPatientService;


/**
 
 *@RequestMapping (@Path)
 *@GetMapping -Get method
 *@PostMapping -Post method
 *@PutMapping -Put method
 *@DeleteMapping -Delete method
 */
//@SuppressWarnings("unused")
@RestController
@RequestMapping(value = "/patient")
public class PatientController {
	private static final Logger logger = LoggerFactory.getLogger(PatientController.class);
	@Autowired
	private IPatientService patientService;
	@Autowired
    private IBillingService billService;

	@GetMapping(path = "/bill/{pId}")
	public ResponseEntity<String> getPatientBill(@PathVariable Integer pId) throws MedicineNotFoundException{
		logger.info("Trying to fetch Patient bill ");
		try {
			String details=billService.generatePatientBill(pId);
			if (details.isEmpty()) {
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			}
			return new ResponseEntity<>(details, HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Record NOT found : ");
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
	}
	
	@GetMapping(path = "/")
	public ResponseEntity<List<Patient>> getAllPatient() throws PatientNotFoundException {
		logger.info("Trying to fetch Patient list ");
		try {
			List<Patient> patient = patientService.getPatientList();

			if (patient.isEmpty()) {
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			}
			return new ResponseEntity<>(patient, HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Record NOT found : ");
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
	}

	// http://localhost:8080/corona/patients/1
	// method to get a single patient using patient id
	@GetMapping(path = "/{id}", produces = "application/json")
	public ResponseEntity<Patient> getPatientById(@PathVariable Integer id) throws PatientNotFoundException {
		Optional<Patient> patient = null;
		logger.info("Trying to search Record with Id : " + id);
		try {
			patient = patientService.getPatientById(id);

			if (patient.isPresent()) {
				return new ResponseEntity<>(patient.get(), HttpStatus.OK);
			} else {
				return new ResponseEntity<>(HttpStatus.NOT_FOUND);
			}
		} catch (Exception e) {
			logger.error("Record NOT Found with Id : " + id);
			return new ResponseEntity<Patient>(new Patient(), HttpStatus.EXPECTATION_FAILED);
		}
	}

	//http://localhost:8080/corona/patients/add
	// method to add a single patient using patient id
	@PostMapping(path = "/add")
	public ResponseEntity<Patient> addPatient(@RequestBody Patient patient) throws PatientNotFoundException {
		try {
			logger.info("Trying to add Record  : " + patient);
			Patient addedPatient = patientService.addPatient(patient);
			return new ResponseEntity<Patient>(addedPatient, HttpStatus.CREATED);
		} catch (Exception e) {
			logger.error("Record NOT Added  : " + patient);
			return new ResponseEntity<>(patient , HttpStatus.EXPECTATION_FAILED);
			
		}
	}
	//http://localhost:8080/corona/patients/1
	//method to delete a single patient using patient id
			
	@DeleteMapping("/{id}")
	public ResponseEntity<String> deletePatient(@PathVariable Integer id) throws PatientNotFoundException {
		
		try {
			patientService.deletePatient(id);
			Optional<Patient> delPatient = patientService.getPatientById(id);
			logger.info("Record Deleted with Id : " + id);
			return new ResponseEntity<>("Record Deleted...with id : "+id,HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Record NOT Deleted with Id : " + id);
			return new ResponseEntity<>("Record not found with id : "+id,HttpStatus.EXPECTATION_FAILED);
		}
	}
	//http://localhost:8080/corona/patients/1
	//method to update a single patient using patient id
			
	@PutMapping("/{id}")
	public ResponseEntity<Object> updatePatient(@RequestBody Patient patient, @PathVariable Integer id)
			throws PatientNotFoundException {
		logger.info("trying to update patient : " + patient);
		try {
			Optional<Patient> patientFound = patientService.getPatientById(id);
			
			if (patientFound.isPresent()) {
				patientService.updatePatient(patient, id);
				System.out.println("Record Updated : " + patient);
				return ResponseEntity.ok(patient);
			} else {
				return new ResponseEntity<>("Record NOT updated with Id : " + patient,HttpStatus.NO_CONTENT);
			}
		} catch (Exception e) {
			logger.error("Record NOT updated with Id : " + patient);
			return new ResponseEntity<>("Record NOT updated with Id : " + patient, HttpStatus.EXPECTATION_FAILED);
		}

	}

}