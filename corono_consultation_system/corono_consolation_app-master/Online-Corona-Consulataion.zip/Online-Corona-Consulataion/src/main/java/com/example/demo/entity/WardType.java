package com.example.demo.entity;
public enum WardType {

	Critical_Care,
	General_Care
	
}
