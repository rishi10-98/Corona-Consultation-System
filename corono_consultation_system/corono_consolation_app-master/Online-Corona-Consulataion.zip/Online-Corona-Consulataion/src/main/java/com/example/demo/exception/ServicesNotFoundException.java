package com.example.demo.exception;

public class ServicesNotFoundException extends RuntimeException {
	/**
	 * 
	 */
	private static final long serialVersionUID = 9171128383494007772L;

	public ServicesNotFoundException() {
		super();
	}
	
	public ServicesNotFoundException(String msg)
	{
		super(msg);
	}
}



