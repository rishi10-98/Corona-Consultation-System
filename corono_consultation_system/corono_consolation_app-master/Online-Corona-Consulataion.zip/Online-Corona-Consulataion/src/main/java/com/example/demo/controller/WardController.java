package com.example.demo.controller;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Ward;
import com.example.demo.exception.WardNotFoundException;
import com.example.demo.service.IWardService;

import io.swagger.annotations.ApiOperation;
@RestController
@RequestMapping(value="/ward")
public class WardController {
	
	private static final Logger logger = LoggerFactory.getLogger(WardController.class);
	@Autowired
	private IWardService wardService;
	/*
	 * http://localhost:8080/ward/add
	 * This particular url is response for adding ward 
	 * HTTP Method post is required
	 */
	@PostMapping(value = "/add")
	@ApiOperation(value  = "This is addWard() method to add a ward  object in database table")
	public ResponseEntity<Ward> addWard(@Valid @RequestBody Ward ward) throws WardNotFoundException {
		try {
			logger.info("Trying to add Record  : " + ward);
			Ward addedWard = wardService.addWard(ward);
			return new ResponseEntity<>(ward, HttpStatus.CREATED);//201
		} catch (Exception e) {
			logger.error("Record NOT Added  : " +ward);
			return new ResponseEntity<>(ward, HttpStatus.EXPECTATION_FAILED);	
		}
	}
	/*
	 * http://localhost:8080/ward/getAll
	 * This particular url is response for getting all ward 
	 * HTTP Method get is required
	 */
	
		@GetMapping(path = "/getAll", produces = "application/json")
		@ApiOperation(value  = "This is getaAllWard() method to get all Ward object from database table")
		public ResponseEntity<List<Ward>> getAllWard() throws WardNotFoundException {
			logger.info("Trying to fetch Ward Report list ");
			try {
				List<Ward> ward = wardService.getWardList();
				if (ward.isEmpty()) {
					return new ResponseEntity<>(HttpStatus.NO_CONTENT);
				}
				return new ResponseEntity<>(ward, HttpStatus.OK);
			} catch (Exception e) {
				logger.error("Record NOT found : ");
				return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
			}
		}
		/*
		 * http://localhost:8080/ward/
		 * This particular url is response for getting single ward
		 * HTTP Method get is required
		 */
		@GetMapping(path = "/singleRecord{wardId}", produces = "application/json")
		@ApiOperation(value  = "This is getWardById() method to get ward object From database table")
		public ResponseEntity<Ward> getWardById(@PathVariable Integer wardId) throws WardNotFoundException {
			Optional<Ward> ward = null;
			logger.info("Trying to search Record with Id : " + wardId);
			try {
				ward= wardService.getWardById(wardId);

				if (ward.isPresent()) {
					return new ResponseEntity<>(ward.get(), HttpStatus.OK);
				} else {
					return new ResponseEntity<>(HttpStatus.NOT_FOUND);
				}
			} catch (Exception e) {
				logger.error("Record NOT Found with Id : " + wardId);
				return new ResponseEntity<Ward>(new Ward(), HttpStatus.EXPECTATION_FAILED);
			}
		}

		/*
		 * http://localhost:8080/ward/getAll
		 * This particular url is response for deleting ward
		 * HTTP Method get is required
		 */
		@DeleteMapping(path="/delete/{wardId}")
		@ApiOperation(value  = "This is deleteWard() method to delete a ward object From database table")
		public ResponseEntity<String> deleteWard(@PathVariable Integer wardId) throws WardNotFoundException {
			
			try {
				wardService.deleteWard(wardId);
				Optional<Ward> delWard = wardService.getWardById(wardId);
				logger.info("Record Deleted with Id : " +wardId);
				return new ResponseEntity<>("Record Deleted...with id : "+wardId,HttpStatus.OK);
			} catch (Exception e) {
				logger.error("Record NOT Deleted with Id : " + wardId);
				return new ResponseEntity<>("Record not found with id : "+wardId,HttpStatus.EXPECTATION_FAILED);
			}
		}
		/*
		 * http://localhost:8080/ward/getAll
		 * This particular url is response for updating data of ward
		 * HTTP Method get is required
		 */

		@PutMapping("/{wardId}")
		@ApiOperation(value  = "This is updateWard() method to update ward object From database table")
		public ResponseEntity<Object> updateWard(@RequestBody Ward ward, @PathVariable Integer wardId)
				throws WardNotFoundException {
			logger.info("trying to update user : " + ward);
			try {
				Optional<Ward> wardFound = wardService.getWardById(wardId);

				if (wardFound.isPresent()) {
					wardService.updateWard(ward, wardId);
					System.out.println("Record Updated : " + ward);
					return ResponseEntity.ok(ward);
				} else {
					return new ResponseEntity<>("Record NOT updated with Id : " + ward,HttpStatus.NO_CONTENT);
				}
			} catch (Exception e) {
				logger.error("Record NOT updated with Id : " + ward);
				return new ResponseEntity<>("Record NOT updated with Id : " + ward, HttpStatus.EXPECTATION_FAILED);
			}

		}
}
