package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import com.example.demo.entity.Employee;
import com.example.demo.exception.MyEmployeeException;

public interface IEmployeeService {
	public Employee saveEmployee(Employee employee) throws MyEmployeeException;
	public List<Employee> getAllEmployees() throws MyEmployeeException;
	public Optional<Employee> getSingleEmployee(Long id) throws MyEmployeeException;
	public Employee updateEmployee(Employee employee, Long id) throws MyEmployeeException;
	public void deleteEmployee(Long id) throws MyEmployeeException;

}
