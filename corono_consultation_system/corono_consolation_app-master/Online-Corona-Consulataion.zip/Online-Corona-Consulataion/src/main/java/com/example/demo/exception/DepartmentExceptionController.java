package com.example.demo.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class DepartmentExceptionController {
   @ExceptionHandler(value = DepartmentNotFoundException.class)
   public ResponseEntity<Object> exception(DepartmentNotFoundException exception) {
      return new ResponseEntity<>("Department not found", HttpStatus.NOT_FOUND);
   }
   @ExceptionHandler(value = MyDepartmentException.class)
   public ResponseEntity<Object> exception(MyDepartmentException exception) {
      return new ResponseEntity<>("Department Bad request", HttpStatus.BAD_REQUEST);
   }
}
