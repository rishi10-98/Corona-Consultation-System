package com.example.demo.exception;


import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class EmployeeExceptionController {
   @ExceptionHandler(value = EmployeeNotFoundException.class)
   public ResponseEntity<Object> exception(EmployeeNotFoundException exception) {
      return new ResponseEntity<>("Employee not found", HttpStatus.NOT_FOUND);
   }
   @ExceptionHandler(value = MyEmployeeException.class)
   public ResponseEntity<Object> exception(MyEmployeeException exception) {
      return new ResponseEntity<>("Employee Bad request", HttpStatus.BAD_REQUEST);
   }
}