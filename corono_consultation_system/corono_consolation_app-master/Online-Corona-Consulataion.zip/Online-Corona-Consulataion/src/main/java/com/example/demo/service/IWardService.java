package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import com.example.demo.entity.Ward;
import com.example.demo.exception.MyWardException;


public interface IWardService {

	public Ward addWard(Ward ward) throws MyWardException;
	public List<Ward> getWardList()throws MyWardException;
	public Optional<Ward> getWardById(Integer wardId) throws MyWardException;
	public void deleteWard(Integer wardId)throws MyWardException; 
	public Ward updateWard(Ward ward, Integer wardId)throws MyWardException;
	
}
