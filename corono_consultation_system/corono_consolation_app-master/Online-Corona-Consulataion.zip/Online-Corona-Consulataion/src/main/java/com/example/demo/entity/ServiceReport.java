package com.example.demo.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

import com.sun.istack.NotNull;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity(name="Service_Report")
@Data
@NoArgsConstructor
@AllArgsConstructor
//ServiceReport Class Which represent ServiceReport Entity in table.
public class ServiceReport {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	//Primary key reportId is Created
	private Integer reportId;
	
	@Column
	@NotNull
	//Column of emergencyExtraCost is Created
	private Integer emergencyExtraCost;
	
	@Column
	@NotNull
	//Column of ventilatorCost is Created
	private Integer ventilatorCost;
	
	
	
	  @OneToOne(cascade=CascadeType.ALL)
	  
	  @JoinColumn(name="serviceId") 
	  private Services services;
	 
	 
	
	

}
