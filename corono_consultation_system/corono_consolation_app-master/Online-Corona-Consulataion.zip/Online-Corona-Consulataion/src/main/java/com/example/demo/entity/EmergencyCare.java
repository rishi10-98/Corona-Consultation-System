package com.example.demo.entity;

public enum EmergencyCare {
	YES,
	NO

}
