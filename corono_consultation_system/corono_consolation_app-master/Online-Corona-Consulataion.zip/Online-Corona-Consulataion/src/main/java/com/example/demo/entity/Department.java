package com.example.demo.entity;
import java.io.Serializable;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Entity
@Table(name="DEPARTMENT")
@NoArgsConstructor
@Data
@AllArgsConstructor
public class Department implements Serializable{
	private static final long serialVersionUID = 6325307718376939175L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY )
	@Column(name="DEPARTMENT_ID")
	private Long depatmentId;
	@Column(name="DEPARTMENT_NAME")
	@NotEmpty(message = "Please provide Department Name")
	private String departmentName;

	
	@OneToMany(cascade = CascadeType.ALL )
	@JoinColumn(name="DepartmentLocation_FK")
	private List<Ward> wards;
	



}