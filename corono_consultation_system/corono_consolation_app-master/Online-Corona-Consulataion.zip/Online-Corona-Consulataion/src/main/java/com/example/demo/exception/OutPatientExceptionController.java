package com.example.demo.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class OutPatientExceptionController {
	
	 @ExceptionHandler(value = OutPatientNotFoundException.class)
	   public ResponseEntity<Object> exception(OutPatientNotFoundException exception) {
	      return new ResponseEntity<>("OutPatient not found", HttpStatus.NOT_FOUND);
	   }
	   @ExceptionHandler(value = MyOutPatientException.class)
	   public ResponseEntity<Object> exception(MyOutPatientException exception) {
	      return new ResponseEntity<>("OutPatient Bad request", HttpStatus.BAD_REQUEST);
	   }

}
