package com.example.demo.exception;
public class MyWardException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public MyWardException() {
		super();
		
	}

	public MyWardException(String message) {
		super(message);
		
	}
}
