package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import com.example.demo.entity.Patient;
import com.example.demo.exception.MyPatientException;


public interface IPatientService {
	public Optional<Patient> getPatientById(Integer patientId) throws MyPatientException;
	public List<Patient> getPatientList()throws MyPatientException;
	public Patient addPatient(Patient patient) throws MyPatientException;

	public Patient updatePatient(Patient patient, Integer patientId)throws MyPatientException;
	public void deletePatient(Integer patientId) throws MyPatientException;
}



