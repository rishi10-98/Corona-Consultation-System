package com.example.demo.entity;

import java.util.List;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.CascadeType;
import javax.persistence.Column;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity(name="Doctor")
@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
//Doctor Class Which represent doctor Entity in table with doctor name
public class Doctor{
	
	/**
	 * 
	 */
	@Id()
	@Column(name="DOCTOR_ID")//Primary key with Auto Generate 
	@GeneratedValue(strategy = GenerationType.IDENTITY)    
	private Long docId;
	
	@Column(name = "DOCTOR_NAME")        //Column of Doctor Name 
	@NotEmpty(message = "Enter Doctor name")
	private String docName;
	
	
	@Column(name="DOCTOR_PHONE_NUM")		// column of Doctor phone number
	@NotEmpty(message = "Enter Phone number of Doctor")
	private String docPhone;
	
	@Column(name = "DOCTOR_GENDER")		//Enum Of Gender 
	@NotNull(message = "Enter Gender of Doctor")
	@Enumerated(EnumType.STRING)
	public Gender gender;
	
	
	@Column(name="DOCTOR_MAIL")		//Column of Doctor Mail
	@NotEmpty(message = "Enter Mail id of Doctor")
	private String docMail;
	
	
	
	@OneToMany(cascade = CascadeType.ALL )
	@JoinColumn(name="patient_doctor_puk")
	List<Patient> patients;
	
	@Embedded
	@AttributeOverrides({
		  @AttributeOverride( name = "doctorCity", column = @Column(name = "doctor_city")),
		  @AttributeOverride( name = "doctorDistict", column = @Column(name = "doctor_distict")),
		  @AttributeOverride( name = "doctorState", column = @Column(name = "doctor_state"))
		})
	private Address adress;
	
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "department_doctor_puk")
	private Department department;


	
}
