package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.repository.IDepartmentdao;
import com.example.demo.entity.Department;
import com.example.demo.entity.Doctor;
import com.example.demo.exception.DoctorNotFoundException;
import com.example.demo.exception.MyDepartmentException;
//Department Service layer
@Service("departmentService")
public class DepartmentService implements IDepartmentService {
	private static final Logger logger = LoggerFactory.getLogger(DepartmentService.class);
	@Autowired
	private IDepartmentdao departmentdao;
	// Getting one department object at a time by department id at service layer
	@Override
	public Optional<Department> getDepartmentById(Long departmentId) throws MyDepartmentException {
		logger.info("Trying to fetch User in service layer ");
		return  Optional.of(departmentdao.findById(departmentId).orElseThrow(()->new DoctorNotFoundException("Doctor with given id "+departmentId+" not Available")));
	}
	// Adding department object at service layer
	@Override
	@Transactional //DML
	public Department addDepartment(Department department) throws MyDepartmentException {
		logger.info("Trying to add Department in service layer "+ department);
		
		// TODO Auto-generated method stub
		return departmentdao.save(department);
	}
	// Updating department object at service layer
	@Override
	@Transactional //DML
	public Department updateDepartment(Department department, Long departmentId) throws MyDepartmentException {
		logger.info("Trying to update Department in service layer ");
		
		// TODO Auto-generated method stub
		
		Optional<Department> departmentFound = getDepartmentById(departmentId);	
		Department exdepartment=departmentdao.getOne(departmentId);
		BeanUtils.copyProperties(department, exdepartment, "depatmentId");
			return departmentdao.save(exdepartment);
	
	}
	// Deleting department object at service layer
	@Override
	@Transactional //DML
	public void deleteDepartment(Long departmentId) throws MyDepartmentException {
		logger.info("Trying to delete Department in service layer ");
		departmentdao.deleteById(departmentId);
	}
	// Getting all department objects at service layer
	@Override
	public List<Department> getDepartmentList() throws MyDepartmentException {
		logger.info("Trying to fetch all Department in service layer ");
		// TODO Auto-generated method stub
		return departmentdao.findAll();
	}

}
