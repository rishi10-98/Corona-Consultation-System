package com.example.demo.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.ServiceReport;
import com.example.demo.exception.ServiceReportNotFoundException;
import com.example.demo.service.IServiceReportService;

import io.swagger.annotations.Api;


@RestController
@RequestMapping	(value="/serviceReport")
@Api(description = "This is Service Report Controller to perform operations on Service Report")
public class ServiceReportController {
	
	@Autowired
	private IServiceReportService eservice;
	
	private final Logger LOGGER = LoggerFactory.getLogger(ServiceReportController.class);
	
	/*
	 * http://localhost:8080/serviceReport/add
	 * This method adding new Service Report.
	 */
	@PostMapping(value="/add")
	public ResponseEntity<ServiceReport> addServiceReport(@Valid @RequestBody ServiceReport sReport) throws ServiceReportNotFoundException
	{
		LOGGER.info("Trying to add Record  : " + sReport);
		try {
			ServiceReport s= eservice.addServiceReport(sReport);
			
			return new ResponseEntity<ServiceReport>(s, HttpStatus.CREATED);
			
		} catch (Exception e) {
			LOGGER.error("Record NOT Added  : " + sReport);
			return new ResponseEntity<ServiceReport>(new ServiceReport(), HttpStatus.EXPECTATION_FAILED);
		}
		
	}
	
	
	/*
	 * http://localhost:8080/serviceReport/getAll
	 * This method show all Service Reports.
	 */
	@GetMapping(value="/getAll")
	public List<ServiceReport> getAllServiceReport(){
		LOGGER.info("Getting All Service Reports");
		return eservice.getAllServiceReport();
	}
	
	/*
	 * http://localhost:8080/serviceReport/get/id
	 * This method gives Service Record with the help of Id.
	 */
	@GetMapping(value="/get/{id}")
	public ResponseEntity<ServiceReport> getServiceReportById(@PathVariable("id") Integer reportId) throws ServiceReportNotFoundException{
		Optional<ServiceReport> ServiceReport = null;
		LOGGER.info("Getting Service Report by giving Report ID");
		try {
			ServiceReport = eservice.getServiceReportById(reportId);

			if (ServiceReport.isPresent()) {
				return new ResponseEntity<ServiceReport>(ServiceReport.get(), HttpStatus.OK);
			} else {
				return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
		}
			catch (Exception e) {
				LOGGER.error("Record NOT Found with Id : " + reportId);
				return new ResponseEntity<ServiceReport>(new ServiceReport(), HttpStatus.EXPECTATION_FAILED);
			}
	}
	
	/*
	 * http://localhost:8080/serviceReport/delete/id
	 * This method deletes the Service report with the help of Id.
	 */
	@DeleteMapping(value="/delete/{id}")
	public ResponseEntity<String> deleteServiceReportById(@PathVariable("id") Integer reportId) throws ServiceReportNotFoundException{
		LOGGER.info("Record Deleted with ID:" +reportId);
		try {
			eservice.deleteServiceReportById(reportId);
			
			return new ResponseEntity<>("Record Deleted...with id : "+reportId,HttpStatus.OK);
		} catch (Exception e) {
			LOGGER.error("Record NOT Deleted with Id : " + reportId);
			return new ResponseEntity<>("Record not found with id : "+reportId,HttpStatus.EXPECTATION_FAILED);
		}
	}
		

	
	/*
	 * http://localhost:8080/serviceReport/update/id
	 * This method update the Service report.
	 */
	@PutMapping(value="/update/{id}")
	public ServiceReport updateServiceReport(@PathVariable("id") Integer reportId,
											@Valid @RequestBody ServiceReport sreport) {
		LOGGER.info("Updating Service Report by giving Report ID");
		return eservice.updateServiceReport(reportId,sreport);
	}
	/*public ResponseEntity<Object> getDoctorReportupdate(@RequestBody ServiceReport serviceReport , @PathVariable Integer reportId ) throws ServiceReportNotFoundException{
		
		LOGGER.info("Trying to update Service Report: " +serviceReport);
		try {
			Optional<ServiceReport> reportFound = eservice.getServiceReportById(reportId);
			if (reportFound.isPresent()) {
				LOGGER.info("user found"+reportFound);
				eservice. updateServiceReport(reportId, serviceReport);					
				System.out.println("Record Updated : " + serviceReport);
				return ResponseEntity.ok(serviceReport);
			} else {
				return new ResponseEntity<>("Record NOT updated with Id : " + serviceReport,HttpStatus.NO_CONTENT);
						
	} 
	}catch (Exception e) {
		LOGGER.error("Record NOT updated with Id : " + serviceReport);
		return new ResponseEntity<>("Record NOT updated with Id : " + serviceReport, HttpStatus.EXPECTATION_FAILED);
	}
	}*/
}
