package com.example.demo.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.repository.IMedicineDao;
import com.example.demo.entity.Medicine;
import com.example.demo.entity.Patient;
import com.example.demo.entity.PatientMedicine;
import com.example.demo.exception.MedicineNotFoundException;
import com.example.demo.repository.IPatientRepository;


import java.util.Iterator;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.List;
@Service
public class BillingServiceImpl implements IBillingService{
	
	@Autowired
	private IMedicineDao medDao;
	
	@Autowired
	private IPatientRepository patRepo;
	
	//private List<String> medNames;
	private Double medBill=0.0,roomBill=0.0,doctorFee=500.0;
	@Override
	public String generatePatientBill(Integer pId) throws MedicineNotFoundException {
		// TODO Auto-generated method stub
		Optional<Patient> optPat=patRepo.findById(pId); //getting patient object to find his bill
		Patient p=optPat.get();
		
		String patientName=p.getPatientName();
		
		List<PatientMedicine> patientMedicines=p.getPatientMedicines(); //getting list of medicines prescribed to the patient
		
		Iterator<PatientMedicine> it= patientMedicines.iterator();
		while(it.hasNext()) {
			PatientMedicine patientMedicine=it.next();
			Integer quantity= patientMedicine.getQuantity();
			Integer mId = patientMedicine.getMId();
			Optional<Medicine> optMed=medDao.findById(mId); //getting the medicine from the medicine id given to patient
			Medicine medicine=optMed.get();
			
			//medNames.add(medicine.getMedName());
			Double medPrice=medicine.getMedPrice();
			medBill+=(medPrice*quantity);
			
		}
		
		/*
		  if(p.inPatient){
		  
		  Date entry=p.getEntryDate();
		  
		  Optional<InPatient> optInPat=inPatRepo.findById(pId);
		Patient ip=optPat.get();
		
		  Date exit=ip.getDischargeDate();
		  
		  long difference=entry.getTime()-exit.getTime();
		  float daysBetween=(difference/(1000*60*60*24));
		  
		  roomBill=(daysBetween*500.0);
		  }
		 */
		
		Double totalBill=medBill+roomBill+doctorFee;
		String details=("Patient Name : "+patientName+ "\n 1) Medicine Charges : "+medBill+"\n 2) Doctor Fee"+doctorFee+"\n 3) Room Charges : "+roomBill+ "\n TOTAL BILL : "+totalBill);
		
			
		return details;
	}
		

}