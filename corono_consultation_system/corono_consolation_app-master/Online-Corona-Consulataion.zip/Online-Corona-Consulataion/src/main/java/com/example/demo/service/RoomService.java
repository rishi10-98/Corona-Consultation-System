package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Room;
import com.example.demo.exception.MyRoomException;
import com.example.demo.repository.RoomRepository;

@Service
public class RoomService implements IRoomService {


	private static final Logger logger = LoggerFactory.getLogger(RoomService.class);
	
	@Autowired
	private RoomRepository roomRepository;
	
	
	@Override
	public Room addRoom(Room room) throws MyRoomException {
		logger.info("Add Ward report in service layer "+ room);
		return roomRepository.save(room);
	}
	
	@Override
	public List<Room> getRoomList() throws MyRoomException {
		logger.info("Fetch all Ward  in service layer ");
		return roomRepository.findAll();
	}

	@Override
	public Optional<Room> getRoomById(Long roomId) throws MyRoomException {
		logger.info("Trying to fetch ward in service layer ");
		return roomRepository.findById(roomId);
	}

	@Override
	public void deleteRoom(Long roomId) throws MyRoomException {
		logger.info("Delete Ward in service layer ");
		roomRepository.deleteById(roomId);
	}

	@Override
	public Room updateRoom(Room room) throws MyRoomException {
		// TODO Auto-generated method stub
		return null;
	}

	

		

}
