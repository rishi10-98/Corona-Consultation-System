package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import springfox.documentation.swagger2.annotations.EnableSwagger2;

@SpringBootApplication
@EnableSwagger2                               //Enabling Swagger
public class DoctorModuleApplication {

	public static void main(String[] args) {
		SpringApplication.run(DoctorModuleApplication.class, args);
	}

}
