package com.example.demo.exception;

public class MyPatientException extends Exception {
	private static final long serialVersionUID = 1L;

	public MyPatientException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public MyPatientException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}

