package com.example.demo.service;

import java.util.List;
import java.util.Optional;
import com.example.demo.entity.OutPatient;
import com.example.demo.exception.MyOutPatientException;

public interface IOutPatientService {
	
	public Optional<OutPatient> getOutPatientById(Integer patientId) throws MyOutPatientException;
	public List<OutPatient> getOutPatientList()throws MyOutPatientException;
	public OutPatient addOutPatient(OutPatient patient) throws MyOutPatientException;

	public OutPatient updateOutPatient(OutPatient patient, Integer patientId)throws MyOutPatientException;
	public void deleteOutPatient(Integer patientId)throws MyOutPatientException;


}
