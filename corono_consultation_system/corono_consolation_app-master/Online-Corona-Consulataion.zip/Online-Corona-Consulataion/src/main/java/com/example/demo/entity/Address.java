package com.example.demo.entity;
import javax.persistence.Embeddable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Embeddable
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Address {
	private static final long serialVersionUID = 1L;

	//private Long addressId;
	
	//private Long docId;
	
	private String city;
	
	//private Long patId;
	
	private String distict;
	
	//private Long staffId;
	
	private String state;
	
	

}
	 
