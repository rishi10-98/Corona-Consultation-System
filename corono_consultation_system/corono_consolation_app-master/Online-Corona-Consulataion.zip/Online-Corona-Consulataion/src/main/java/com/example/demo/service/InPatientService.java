package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.controller.InPatientController;
import com.example.demo.repository.IPatientRepository;
import com.example.demo.repository.InPatientDao;
import com.example.demo.entity.InPatient;
import com.example.demo.entity.Patient;
import com.example.demo.exception.MyInPatientException;

@Service
public class InPatientService implements IInPatientService
{
		private static final Logger logger = LoggerFactory.getLogger(InPatientService.class);
	// inject Dao Object
		@Autowired
		private IPatientRepository patRepo;
		@Autowired
		private InPatientDao inPatientDao;
	@Override
	public InPatient addInPatientById(Integer pId) {
		Optional<Patient> optPat=patRepo.findById(pId);
		Patient patient=optPat.get();

		InPatient inPatient=new InPatient(patient.getPatientId(),patient.getPatientName(),
				patient.getPatientNum(),patient.getPatientAge(),patient.getGender(),
				patient.getPatientMedicines(),patient.getPatientDoctor()
				,patient.getPatientRoomnum(),"2019-07-07");
				
		InPatient result= new InPatient();
		result.setGender(patient.getGender());
		result.setPatientId(patient.getPatientId());
		
		InPatient savedInPatient=inPatientDao.save(inPatient);
		return savedInPatient;
		
		
	}

	}



