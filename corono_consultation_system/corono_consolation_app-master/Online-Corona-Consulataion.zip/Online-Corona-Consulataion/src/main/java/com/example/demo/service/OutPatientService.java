package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.repository.OutPatientDao;
import com.example.demo.entity.Doctor;
import com.example.demo.entity.OutPatient;
import com.example.demo.exception.MyOutPatientException;

@Service
public class OutPatientService implements IOutPatientService{
	
	private static final Logger logger = LoggerFactory.getLogger(OutPatientService.class);
	// inject Dao Object
		@Autowired
		private OutPatientDao patientDao;

		@Override
		public Optional<OutPatient> getOutPatientById(Integer patientId) throws MyOutPatientException {
			logger.info("Trying to fetch OutPatient in service layer ");
	//prep work 4-> call and return dao method in specific service method
			return patientDao.findById(patientId);
		}

		@Override
		@Transactional 
		public OutPatient addOutPatient(OutPatient patient) throws MyOutPatientException {
			logger.info("Trying to add OutPatient in service layer "+ patient);
			
			return patientDao.save(patient);
		}

		@Override
		@Transactional 
		public OutPatient updateOutPatient(OutPatient patient, Integer patientId) throws MyOutPatientException {
			logger.info("Trying to update OutPatient in service layer ");
			
			Optional<OutPatient> outPatientFound = getOutPatientById(patientId);	
			OutPatient exOutPatient=patientDao.getOne(patientId);
			BeanUtils.copyProperties(patient, exOutPatient, "patientId");
				return patientDao.save(exOutPatient);
		}

		@Override
		@Transactional
		public void deleteOutPatient(Integer patientId) throws MyOutPatientException {
			logger.info("Trying to delete OutPatient in service layer ");
			 patientDao.deleteById(patientId);
		}

		@Override
		public List<OutPatient> getOutPatientList() throws MyOutPatientException {
			logger.info("Trying to fetch all OutPatient in service layer ");
			
			return patientDao.findAll();
		}

}
