package com.example.demo.controller;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Medicine;
import com.example.demo.exception.MedicineNotFoundException;
import com.example.demo.service.IBillingService;
import com.example.demo.service.IMedicineService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(value = "/medicines")
@Api(description = "This is medicine Controller")
public class MedicineController {
	
	  private static final Logger logger = LoggerFactory.getLogger(MedicineController.class);
	 
	  
	  @Autowired
	  private IMedicineService medService;
	  
	  
	  // http://localhost:8080/corona/medicines/
	  //Method to get all medicines
		
		@CrossOrigin("*")
		@GetMapping(path = "/", produces = "application/json")
		@ApiOperation(value="Method to get list of all medicines")
		public ResponseEntity<Object> getAllMedicines() throws MedicineNotFoundException {
			logger.info("Trying to fetch all Medicines list ");
			try {
				List<Medicine> medicines = medService.getMedicineList();

				if (medicines.isEmpty()) {
					return new ResponseEntity<>(HttpStatus.NO_CONTENT);
				}
				return new ResponseEntity<>(medicines, HttpStatus.OK);
			} catch (Exception e) {
				logger.error("Record NOT found : ");
				return new ResponseEntity<>("Record Not Found", HttpStatus.INTERNAL_SERVER_ERROR);
			}
			
		}

		// http://localhost:8080/corona/medicines/1
		// method to get a single medicine using medicine id
		
		@GetMapping(path = "/{mId}", produces = "application/json")
		@ApiOperation(value="Method to get a medicine with given medicine Id")
		public ResponseEntity<Medicine> getMedicineById(@PathVariable Integer mId) throws MedicineNotFoundException {
			Optional<Medicine> medicine = null;
			logger.info("Trying to search Record with Id : " + mId);
			try {
				medicine = medService.getMedicineById(mId);

				if (medicine.isPresent()) {
					return new ResponseEntity<>(medicine.get(), HttpStatus.OK);
				} else {
					return new ResponseEntity<>(HttpStatus.NOT_FOUND);
				}
			} catch (Exception e) {
				logger.error("Record NOT Found with Id : " + mId);
				return new ResponseEntity<Medicine>(new Medicine(), HttpStatus.EXPECTATION_FAILED);
			}
		}

		//http://localhost:8080/corona/medicines/add
		// method to add a single medicine using medicine id
		
		@PostMapping(path = "/add")
		@ApiOperation(value="Method to add a medicine")
		public ResponseEntity<Object> addMedicine(@RequestBody Medicine medicine) throws MedicineNotFoundException {
			try {
				logger.info("Trying to add Record  : " + medicine);
				Medicine addedMedicine = medService.addMedicine(medicine);
				return new ResponseEntity<>(medicine, HttpStatus.CREATED);//201
			} catch (Exception e) {
				logger.error("Record NOT Added  : " + medicine);
				return new ResponseEntity<>("Record not Added", HttpStatus.EXPECTATION_FAILED);
				
			}
		}

		//http://localhost:8080/corona/medicines/1
		//method to delete a single medicine using medicine id
		
		@DeleteMapping("/{mId}")
		@ApiOperation(value="Method to delete a medicine with given medicine Id")
		public ResponseEntity<String> deleteMedicine(@PathVariable Integer mId) throws MedicineNotFoundException {
			
			try {
				medService.deleteMedicine(mId);
				Optional<Medicine> delMedicine = medService.getMedicineById(mId);
				logger.info("Record Deleted with Id : " + mId);
				return new ResponseEntity<>("Record Deleted...with id : "+mId,HttpStatus.OK);
			} catch (Exception e) {
				logger.error("Record NOT Deleted with Id : " + mId);
				return new ResponseEntity<>("Record not found with id : "+mId,HttpStatus.EXPECTATION_FAILED);
			}
		}

		//http://localhost:8080/corona/medicines/1
		//method to update a single medicine using medicine id
		
		@PutMapping("/{mId}")
		@ApiOperation(value="Method to update a medicine with given medicine Id")
		public ResponseEntity<Object> updateMedicine(@RequestBody Medicine medicine, @PathVariable Integer mId)
				throws MedicineNotFoundException {
			logger.info("trying to update medicine : " + medicine);
			try {
				Optional<Medicine> medicineFound = medService.getMedicineById(mId);

				if (medicineFound.isPresent()) {
					medService.updateMedicine(medicine);
					System.out.println("Record Updated : " + medicine);
					return ResponseEntity.ok(medicine);
				} else {
					return new ResponseEntity<>("Record NOT updated with Id : " + medicine,HttpStatus.NO_CONTENT);
				}
			} catch (Exception e) {
				logger.error("Record NOT updated with Id : " + medicine);
				return new ResponseEntity<>("Record NOT updated with Id : " + medicine, HttpStatus.EXPECTATION_FAILED);
			}

		}
	 
}
