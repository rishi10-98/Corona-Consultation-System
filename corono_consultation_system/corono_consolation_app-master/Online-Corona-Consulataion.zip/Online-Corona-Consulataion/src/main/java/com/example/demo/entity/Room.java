package com.example.demo.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;

import javax.persistence.Embedded;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Entity
@Data
public class Room {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long roomId;

	@Column(name = "Room_Type")
	private String roomType;
	
	@Column(name="Room_Loc")
	@Enumerated(EnumType.STRING)
	private RoomLocation roomLoc;

	@Column
	private Long totalBeds;

	@Column
	private Long availableBeds;

	@Embedded
    private WardReport wardReport;
	
//	@Embedded
//	private RoomReport roomReport;
	
	/*
	 * @OneToOne(cascade = CascadeType.ALL)
	 * 
	 * @JoinColumn(name = "Employee") private Employee employee;
	 */
	

}