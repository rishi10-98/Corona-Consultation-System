package com.example.demo.entity;

import javax.persistence.Embeddable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Embeddable
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
//DoctorReport Class created to represent Doctor Report in database
public class DoctorReport{

	private Integer reportId;
	
	private String patientPrescrition;
	
	private String medicineToPatient;
	
	private Double docFees;
	
}
