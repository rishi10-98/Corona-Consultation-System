package com.example.demo.controller;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Employee;
import com.example.demo.exception.EmployeeNotFoundException;
import com.example.demo.exception.MyEmployeeException;
import com.example.demo.service.IEmployeeService;

import io.swagger.annotations.ApiOperation;

/*@GetMapping -Get method
@PostMapping -Post method
@PutMapping -Put method
@DeleteMapping -Delete method
http://localhost:8080/
*/

@RestController
@RequestMapping(value="/api/employees")

public class EmployeeController {
	private static final Logger logger = LoggerFactory.getLogger(EmployeeController.class);
	@Autowired
	private IEmployeeService employeeServices;
	
	//http://localhost:8080/api/employees/
	@GetMapping(path = "/", produces = "application/json")
	public ResponseEntity<List<Employee>> getAllEmployees() throws MyEmployeeException {
		//Returns list of all employees in the table
		logger.info("Trying to fetch Employee list ");
		try {
			List<Employee> employees = employeeServices.getAllEmployees();

			if (employees.isEmpty()) {
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			}
			else
			return new ResponseEntity<>(employees, HttpStatus.OK);
		} 
		catch (Exception e) {
			logger.error("Record NOT found : ");
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	//http://localhost:8080/api/employees/{id}
	@GetMapping(value = "/{id}", produces = "application/json")
	@ApiOperation(value = "Provide Employee Id as an input and it returns Employee Object")
	// value passed along with url ,variable passed along with path
	public ResponseEntity<Employee> getSingleEmployee(@PathVariable Long id) throws MyEmployeeException {
		Optional<Employee> employee = null;
		logger.info("Trying to search Record with Id : " + id);
		try {
			employee = employeeServices.getSingleEmployee(id);

			if (employee.isPresent()) {
				return new ResponseEntity<>(employee.get(), HttpStatus.OK);
			} 
			else {
				return new ResponseEntity<>(HttpStatus.NOT_FOUND);
			}
		} 
		catch (Exception e) {
			logger.error("Record NOT Found with Id : " + id);
			return new ResponseEntity<Employee>( HttpStatus.EXPECTATION_FAILED);
		}
	}
	
	//http://localhost:8080/api/employees/saveEmployee
	@PostMapping(path = "/saveEmployee")
	public ResponseEntity<Employee> saveEmployee(@RequestBody Employee employee) throws EmployeeNotFoundException {
		try {
			logger.info("Trying to add Record  : " + employee);
			Employee savedEmployee = employeeServices.saveEmployee(employee);
			return new ResponseEntity<Employee>(savedEmployee, HttpStatus.CREATED);//201
		} catch (Exception e) {
			logger.error("Record NOT Added  : " + employee);
			return new ResponseEntity<>(employee, HttpStatus.EXPECTATION_FAILED);//417
			
		}
	}
	
	//http://localhost:8080/api/employees/{id}
	@DeleteMapping("/{id}")
	public ResponseEntity<String> deleteEmployee(@PathVariable Long id) throws MyEmployeeException {
		
		try {
			employeeServices.deleteEmployee(id);
			Optional<Employee> delEmp = Optional.empty();
			logger.info("Record Deleted with Id : " + id);
			return new ResponseEntity<>("Record Deleted...with id : "+id,HttpStatus.OK);
		} 
		catch (Exception e) {
			logger.error("Record NOT Deleted with Id : " + id);
			return new ResponseEntity<>("Record not found with id : "+id,HttpStatus.EXPECTATION_FAILED);
		}
	}
	
	//http://localhost:8080/api/employees/{id}
	@PutMapping("/{id}")
	public ResponseEntity<Object> updateEmployee(@RequestBody Employee employee, @PathVariable Long id)
			throws MyEmployeeException {
		logger.info("trying to update employee : " + employee);
		try {
			Optional <Employee> empFound = employeeServices.getSingleEmployee(id);

			if (empFound.isPresent()) {
				employeeServices.updateEmployee(employee, id);
				System.out.println("Record Updated : " + employee);
				return ResponseEntity.ok(employee);
			} else {
				return new ResponseEntity<>("Record NOT updated with Id : " + employee,HttpStatus.NO_CONTENT);
			}
		} catch (Exception e) {
			logger.error("Record NOT updated with Id : " + employee);
			return new ResponseEntity<>("Record NOT updated with Id : " + employee, HttpStatus.EXPECTATION_FAILED);
		}

	}
	
}
