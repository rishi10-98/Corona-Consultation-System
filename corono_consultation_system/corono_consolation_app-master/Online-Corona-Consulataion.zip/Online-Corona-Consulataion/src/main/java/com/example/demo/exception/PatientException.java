package com.example.demo.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class PatientException {

   @ExceptionHandler(value = PatientNotFoundException.class)
   public ResponseEntity<Object> exception(PatientNotFoundException exception) {
      return new ResponseEntity<>("Patient not found", HttpStatus.NOT_FOUND);
   }
   @ExceptionHandler(value = MyPatientException.class)
   public ResponseEntity<Object> exception(MyPatientException exception) {
      return new ResponseEntity<>("Patient Bad request", HttpStatus.BAD_REQUEST);
   }
}