package com.example.demo.controller;

import javax.validation.Valid;

//import org.hibernate.annotations.common.util.impl.Log_.logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
//import org.springframework.validation.annotation.Validated;
//import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Services;
import com.example.demo.service.IServicesService;

//import com.google.common.base.Optional;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController//used to create RESTful web services using Spring MVC. 
@RequestMapping(value = "/service1")//used to map Spring MVC controller methods, 
//This annotation maps HTTP requests to handler methods of MVC and REST controllers.
@Api(description = "This is Services Controller to perform operations on sevices")
public class ServicesController {
	
	//HAS-A Relationship
	@Autowired//to auto wire a bean without creating an object with different keyword
	private IServicesService hservice;

	/*
	 * http://localhost:8080/service1/saveServices
	 * This particular url is response for saving a service
	 * HTTP Method post is required
	 */
	@PostMapping(value = "/saveEmployee")//it used to handle post type of request.
    @ApiOperation(value  = "This is saveServices() method to save an service object in database table")
	public ResponseEntity<Services> saveServices(@Valid @RequestBody Services service1)
	{
		Services s=hservice.saveServices(service1);
		return new ResponseEntity<Services>(s,HttpStatus.CREATED);
	}
	
	
	/*
	 * http://localhost:8080/service1/1
	 */
	@GetMapping(value = "/{serviceId}")
	@ApiOperation(value = "Provide Services Id as an input and it returns Services Object")
	public ResponseEntity<Services> getService(@PathVariable Integer serviceId)
	{
		Services s=hservice.getService(serviceId);
		return new ResponseEntity<Services>(s,HttpStatus.OK);
		
	}

	// http://localhost:8080/api/service/1
	
	@DeleteMapping(value="/{serviceId}")
	@ApiOperation(value="delete Service id")
	public ResponseEntity<?> deleteService(@PathVariable Integer serviceId)
	{
		hservice.deleteService(serviceId);
		return new ResponseEntity<String>("Service id: " + serviceId + "deleted successfully", HttpStatus.OK);
	}
	
	
	// http://localhost:8080/api/services/1
		@PutMapping(value="/{serviceId}")
		@ApiOperation(value="put Service id")
		public ResponseEntity<Services> updateSingleService(@PathVariable Integer serviceId, @RequestBody Services service)
		{
			Services s = hservice.updateService(serviceId, service);
			return new ResponseEntity<Services>(s,HttpStatus.OK);
		}
	
	
}