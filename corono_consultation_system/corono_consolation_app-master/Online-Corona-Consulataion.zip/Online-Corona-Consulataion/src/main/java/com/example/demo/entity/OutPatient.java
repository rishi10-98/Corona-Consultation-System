package com.example.demo.entity;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

	@NoArgsConstructor
	@AllArgsConstructor
	@Data
	@Entity
	public class OutPatient implements Serializable
	{
		//patientId; patientName; doctorInConsultation; diagnosisRoom; medicinesPrescribed;
		private static final long serialVersionUID = 6325307718376939175L;
		@Id
		@GeneratedValue(strategy = GenerationType.IDENTITY)
		private Integer patientId;
		@Column
		@NotEmpty(message="please provide patient name")
		private String patientName; //patient name is taken as primary ID.
		@Column
		@NotNull(message="please provide doctor ID")
		private Integer doctorInConsultation; // details of doctor will be shown when doctorId is entered.
		@Column
		@NotNull(message="please provide diagnosisRoom ")
		private Integer diagnosisRoom;
		@Column
		@NotEmpty(message="please provide medicine")
		private String medicinesPrescribed;
		
		// setters and getters
		public String getPatientName() {
			return patientName;
		}
		
		public void setPatientName(String patientName) {
			this.patientName = patientName;
		}
		
		public Integer getDoctorInConsultation() {
			return doctorInConsultation;
		}
		
		public void setDoctorInConsultation(Integer doctorInConsultation) {
			this.doctorInConsultation = doctorInConsultation;
		}
		
		public Integer getDiagnosisRoom() {
			return diagnosisRoom;
		}
		
		public void setDiagnosisRoom(Integer diagnosisRoom) {
			this.diagnosisRoom = diagnosisRoom;
		}
		
		
		public String getMedicinesPrescribed() {
			return medicinesPrescribed;
		}
		
		public void setMedicinesPrescribed(String medicinesPrescribed) {
			this.medicinesPrescribed = medicinesPrescribed;
		}

		public Integer getPatientId() {
			return patientId;
		}

		public void setPatientId(Integer patientId) {
			this.patientId = patientId;
		}
		
		@OneToOne(cascade=CascadeType.ALL)
		  
		  @JoinColumn(name="serviceId") 
		  private Services services;
		/*public static long getSerialversionuid() {
			return serialVersionUID;
		}*/

			
	}



