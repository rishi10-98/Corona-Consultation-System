package com.example.demo.entity;


import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
//import javax.validation.constraints.NotEmpty;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity//to represent class as a table
@AllArgsConstructor// constructors with arguments
@NoArgsConstructor//constructors with no arguments
@Data//to generate getter setter
public class Services {
	
	public Integer getServiceId() {
		return serviceId;
	}
	public void setServiceId(Integer serviceId) {
		this.serviceId = serviceId;
	}
	public Integer getVentilatorsNo() {
		return ventilatorsNo;
	}
	public void setVentilatorsNo(Integer ventilatorsNo) {
		this.ventilatorsNo = ventilatorsNo;
	}
	public AmbulanceStatus getAmbulanceStatus() {
		return ambulanceStatus;
	}
	public void setAmbulanceStatus(AmbulanceStatus ambulanceStatus) {
		this.ambulanceStatus = ambulanceStatus;
	}
	public EmergencyCare getEmergencyCare() {
		return emergencyCare;
	}
	public void setEmergencyCare(EmergencyCare emergencyCare) {
		this.emergencyCare = emergencyCare;
	}
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO	)// to generate strategic primary key automatically.
	private Integer serviceId;
	@Column
	private Integer ventilatorsNo;
	@Column
	//@NotEmpty(message = "please tell ambulance status")
	@Enumerated(EnumType.STRING)
	private AmbulanceStatus ambulanceStatus;
	@Column
	//@NotEmpty(message = "Emergency care in the hospital")
	@Enumerated(EnumType.STRING)
	private  EmergencyCare emergencyCare;
	
	 @OneToOne(cascade=CascadeType.ALL)
	  
	  @JoinColumn(name="reportId") 
	  ServiceReport serviceReport;
}
