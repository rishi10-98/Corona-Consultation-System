package com.example.demo.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Room;
import com.example.demo.entity.Ward;
import com.example.demo.exception.RoomNotFoundException;
import com.example.demo.exception.WardNotFoundException;
import com.example.demo.service.IRoomService;

import io.swagger.annotations.ApiOperation;
;

@RestController
@RequestMapping(value="/room")
public class RoomController {

	

	private static final Logger logger = LoggerFactory.getLogger(WardController.class);
	@Autowired
	private IRoomService roomService;
	/*
	 * http://localhost:8080/wardReport/add
	 * This particular url is response for adding room 
	 * HTTP Method post is required
	 */
	@PostMapping(value = "/add")
	@ApiOperation(value  = "This is addRoom() method to add room object From database table")
	public ResponseEntity<Room> addRoom(@Valid @RequestBody Room room) throws RoomNotFoundException {
		try {
			logger.info("Trying to add Record  : " + room);
			Room addedRoom = roomService.addRoom(room);
			return new ResponseEntity<>(addedRoom, HttpStatus.CREATED);//201
		} catch (Exception e) {
			logger.error("Record NOT Added  : " +room);
			return new ResponseEntity<>(room, HttpStatus.EXPECTATION_FAILED);	
		}
	}
	/*
	 * http://localhost:8080/wardReport/getAll
	 * This particular url is response for getting all room
	 * HTTP Method get is required
	 */
	@GetMapping(path = "/getAll", produces = "application/json")
	@ApiOperation(value  = "This is getAllRoom() method to get all room object From database table")
	public ResponseEntity<List<Room>> getAllRoom() throws RoomNotFoundException {
		logger.info("Trying to fetch Ward Report list ");
		try {
			List<Room> room = roomService.getRoomList();
			if (room.isEmpty()) {
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			}
			return new ResponseEntity<>(room, HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Record NOT found : ");
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	/*
	 * http://localhost:8080/wardReport/
	 * This particular url is response for getting single room
	 * HTTP Method get is required
	 */
	@GetMapping(path = "/singleRecord{roomId}", produces = "application/json")
	@ApiOperation(value  = "This is getRoomById() method to single room object From database table")
	public ResponseEntity<Room> getRoomById(@PathVariable Long roomId) throws RoomNotFoundException {
		Optional<Room> room = null;
		logger.info("Trying to search Record with Id : " + roomId);
		try {
			room= roomService.getRoomById(roomId);

			if (room.isPresent()) {
				return new ResponseEntity<>(room.get(), HttpStatus.OK);
			} else {
				return new ResponseEntity<>(HttpStatus.NOT_FOUND);
			}
		} catch (Exception e) {
			logger.error("Record NOT Found with Id : " + roomId);
			return new ResponseEntity<Room>(new Room(), HttpStatus.EXPECTATION_FAILED);
		}
	}

	/*
	 * http://localhost:8080/wardReport/getAll
	 * This particular url is response for deleting ward
	 * HTTP Method get is required
	 */
	@DeleteMapping(path="/delete/{roomId}")
	@ApiOperation(value  = "This is deleteRoom() method to delete room object From database table")
	public ResponseEntity<String> deleteWard(@PathVariable Long roomId) throws RoomNotFoundException {
		
		try {
			roomService.deleteRoom(roomId);
			Optional<Room> delRoom = roomService.getRoomById(roomId);
			logger.info("Record Deleted with Id : " +roomId);
			return new ResponseEntity<>("Record Deleted...with id : "+roomId,HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Record NOT Deleted with Id : " + roomId);
			return new ResponseEntity<>("Record not found with id : "+roomId,HttpStatus.EXPECTATION_FAILED);
		}
	}
	/*
	 * http://localhost:8080/ward/getAll
	 * This particular url is response for updating data of room
	 * HTTP Method get is required
	 */

	@PutMapping("/{roomId}")
	@ApiOperation(value  = "This is updateRoom() method to update room object From database table")
	public ResponseEntity<Object> updateWard(@RequestBody Room room, @PathVariable Long roomId)
			throws RoomNotFoundException {
		logger.info("trying to update user : " + room);
		try {
			Optional<Room> roomFound = roomService.getRoomById(roomId);

			if (roomFound.isPresent()) {
				roomService.updateRoom(room);
				System.out.println("Record Updated : " + room);
				return ResponseEntity.ok(room);
			} else {
				return new ResponseEntity<>("Record NOT updated with Id : " + room,HttpStatus.NO_CONTENT);
			}
		} catch (Exception e) {
			logger.error("Record NOT updated with Id : " + room);
			return new ResponseEntity<>("Record NOT updated with Id : " +room, HttpStatus.EXPECTATION_FAILED);
		}

	}
	

	
}
