package com.example.demo.entity;

public enum RoomLocation {

	A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,
}
