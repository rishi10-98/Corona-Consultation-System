package com.example.demo.entity;


import java.time.LocalDate;
import java.util.List;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import javax.validation.constraints.NotEmpty;
@NoArgsConstructor
@AllArgsConstructor
@Data
@Entity
public class Patient {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer patientId;
	
	@Column
	@NotEmpty(message = "please provide patient name")
	private String patientName;
	
	@Column
	private Long patientNum;
	
		
	@Column
	private Integer patientAge;
	
	@Column 
	@Enumerated(EnumType.STRING)
	public Gender gender;
	
	@Column 
	private Integer patientRoomnum;
	
	@OneToMany(targetEntity=PatientMedicine.class,cascade=CascadeType.ALL)
	@JoinColumn(name="pId_fk",referencedColumnName="patientId")
	private List<PatientMedicine> patientMedicines;
	
	@Column
	private String patientDoctor;
	
	@Column
	private boolean inPatient;
	
	@Column
	private LocalDate date;
	
	@Embedded
	@AttributeOverrides({
		  @AttributeOverride( name = "patientCity", column = @Column(name = "patient_city")),
		  @AttributeOverride( name = "patientDistict", column = @Column(name = "patient_distict")),
		  @AttributeOverride( name = "patientState", column = @Column(name = "patient_state"))
		})
	private Address adress;
	
	}