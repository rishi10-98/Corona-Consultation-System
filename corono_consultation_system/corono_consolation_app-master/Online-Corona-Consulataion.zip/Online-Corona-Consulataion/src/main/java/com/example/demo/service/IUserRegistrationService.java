package com.example.demo.service;

import com.example.demo.entity.UserRegistration;

public interface IUserRegistrationService {
    public UserRegistration saveUser(UserRegistration user);
}
