package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import com.example.demo.entity.Department;
import com.example.demo.exception.MyDepartmentException;

public interface IDepartmentService {
	public Optional<Department> getDepartmentById(Long depatmentId) throws MyDepartmentException;
	public List<Department> getDepartmentList()throws MyDepartmentException;
	public Department addDepartment(Department Department) throws MyDepartmentException;

	public Department updateDepartment(Department Department, Long departmentId)throws MyDepartmentException;
	public void deleteDepartment(Long depatmentId)throws MyDepartmentException; 
}
