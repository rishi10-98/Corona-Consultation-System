package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import com.example.demo.entity.Doctor;
import com.example.demo.entity.DoctorReport;
import com.example.demo.exception.myDoctorException;
import com.example.demo.exception.myDoctorReportException;


public interface IDoctorService {

	public Doctor addDoctor(Doctor doctor) throws myDoctorException;
	public List<Doctor>getAllDoctor() throws myDoctorException;
	public Optional<Doctor> getDoctorWithId(Long docId) throws myDoctorException;
	public Doctor getDoctorupdate(Doctor doctor, Long docId ) throws myDoctorException;
	public void deleteDoctor(Long docId) throws myDoctorException;
	public List<Doctor> getDoctorByName(String name) throws myDoctorException;
	
	public DoctorReport addDoctorReport(DoctorReport doctorReport) throws myDoctorReportException;
	
}
