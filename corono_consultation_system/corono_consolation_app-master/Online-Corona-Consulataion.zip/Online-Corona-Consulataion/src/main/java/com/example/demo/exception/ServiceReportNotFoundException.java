package com.example.demo.exception;

public class ServiceReportNotFoundException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ServiceReportNotFoundException() {
		super();
	}

	public ServiceReportNotFoundException(String message) {
		super(message);
	}
}
