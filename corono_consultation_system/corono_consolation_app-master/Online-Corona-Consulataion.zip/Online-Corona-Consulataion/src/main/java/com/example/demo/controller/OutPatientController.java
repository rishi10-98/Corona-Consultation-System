package com.example.demo.controller;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.OutPatient;
import com.example.demo.exception.OutPatientNotFoundException;
import com.example.demo.service.IOutPatientService;


@RestController
@RequestMapping(value="/api/outpatient")
public class OutPatientController {
		
		private static final Logger logger = LoggerFactory.getLogger(OutPatientController.class);
		@Autowired
		private IOutPatientService outpatientService;
	
		/*
		 * @ResponseBody
		 */
		// http://localhost:8080/api/ALLOutPatients/
		
		@GetMapping(value = "/AllOutPatients")
		public ResponseEntity<List<OutPatient>> getAllOutPatients() throws OutPatientNotFoundException {
			logger.info("Trying to fetch OutPatient list ");
			try {
				List<OutPatient> patients = outpatientService.getOutPatientList();
	
				if (patients.isEmpty()) {
					return new ResponseEntity<>(HttpStatus.NO_CONTENT);
				}
				return new ResponseEntity<>(patients, HttpStatus.OK);
			} catch (Exception e) {
				logger.error("Record NOT found : ");
				return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
			}
		}
	
	// http://localhost:8080/api/patients/1	
		
		@GetMapping(path = "/{id}", produces = "application/json")
		// value passed along with url ,variable passed along with path
		public ResponseEntity<OutPatient> getOutPatientById(@PathVariable Integer id) throws OutPatientNotFoundException {
			Optional<OutPatient> patient = null;
			logger.info("Trying to search Record with Id : " + id);
			try {
				patient = outpatientService.getOutPatientById(id);
	
				if (patient.isPresent()) {
					return new ResponseEntity<>(patient.get(), HttpStatus.OK);
				} else {
					return new ResponseEntity<>(HttpStatus.NOT_FOUND);
				}
			} catch (Exception e) {
				logger.error("Record NOT Found with Id : " + id);
				return new ResponseEntity<OutPatient>(new OutPatient(), HttpStatus.EXPECTATION_FAILED);
			}
		}
	
		// http://localhost:8080/api/add
		
		@PostMapping(path = "/add")
		public ResponseEntity<OutPatient> addOutPatient(@RequestBody OutPatient patient) throws OutPatientNotFoundException {
			try {
				logger.info("Trying to add Record  : " + patient);
				OutPatient addedOutPatient = outpatientService.addOutPatient(patient);
				return new ResponseEntity<>(patient, HttpStatus.CREATED);//201
			} catch (Exception e) {
				logger.error("Record NOT Added  : " + patient);
				return new ResponseEntity<>(null, HttpStatus.EXPECTATION_FAILED);
				
			}
		}
	
		// http://localhost:8080/api/1
		@DeleteMapping("/{id}")
		public ResponseEntity<String> deleteOutPatient(@PathVariable Integer id) throws OutPatientNotFoundException {
			
			try {
				outpatientService.deleteOutPatient(id);
				Optional<OutPatient> delOutPatient = outpatientService.getOutPatientById(id);
				logger.info("Record Deleted with Id : " + id);
				return new ResponseEntity<>("Record Deleted...with id : "+id,HttpStatus.OK);
			} catch (Exception e) {
				logger.error("Record NOT Deleted with Id : " + id);
				return new ResponseEntity<>("Record not found with id : "+id,HttpStatus.EXPECTATION_FAILED);
			}
		}
	
		// http://localhost:8080/api/1
		@PutMapping("/{id}")
		public ResponseEntity<Object> updateOutPatient(@RequestBody OutPatient patient, @PathVariable Integer id)
				throws OutPatientNotFoundException {
			logger.info("trying to update patient : " + patient);
			try {
				Optional<OutPatient> patientFound = outpatientService.getOutPatientById(id);
	
				if (patientFound.isPresent()) {
					outpatientService.updateOutPatient(patient,id);
					System.out.println("Record Updated : " + patient);
					return ResponseEntity.ok(patient);
				} else {
					return new ResponseEntity<>("Record NOT updated with Id : " + patient,HttpStatus.NO_CONTENT);
				}
			} catch (Exception e) {
				logger.error("Record NOT updated with Id : " + patient);
				return new ResponseEntity<>("Record NOT updated with Id : " + patient, HttpStatus.EXPECTATION_FAILED);
			}
	
		}
	
	}



