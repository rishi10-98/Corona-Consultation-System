package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.ServiceReport;
import com.example.demo.exception.myServiceReportException;
import com.example.demo.repository.ServiceReportRepository;

@Service
public class ServiceReportServiceImpl implements IServiceReportService {
	@Autowired
	private ServiceReportRepository srepo;
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ServiceReport.class);
	
	//Adding new Service Report.
	@Override
	public ServiceReport addServiceReport(ServiceReport sreport) throws myServiceReportException{
		ServiceReport sRReport=srepo.save(sreport);
		LOGGER.info("Adding Service report in service layer");
		return sRReport;
	}

	//Getting all Service Report.
	@Override
	public List<ServiceReport> getAllServiceReport() {
		LOGGER.info("Getting Service report in service layer");
		return srepo.findAll();
	}

	//Getting single Service Report by Id.
	@Override
	public Optional<ServiceReport> getServiceReportById(Integer reportId) throws myServiceReportException{
		LOGGER.info("Get single Service report by reportId");
		return srepo.findById(reportId);
		
	}

	//Deleting Service Report by Id.
	@Override
	public void deleteServiceReportById(Integer reportId) throws myServiceReportException{
		LOGGER.info("Deleting Service report by Id");
		srepo.deleteById(reportId);
	}

	//Updating Service Report by Id.
	@Override
	public ServiceReport updateServiceReport(Integer reportId, ServiceReport sreport) {
		ServiceReport sReportDB=srepo.findById(reportId).get();
		
		sReportDB.setEmergencyExtraCost(sreport.getEmergencyExtraCost());
		sReportDB.setVentilatorCost(sreport.getVentilatorCost());
		LOGGER.info("Updating Service Report by giving Report ID");
		return srepo.save(sReportDB);
	}
	
	

}
