package com.example.demo.exception;

public class myDoctorException extends RuntimeException {

	/**
	 *Class to Handle Exception in Doctor Controller
	 */
	private static final long serialVersionUID = 1L;

	public myDoctorException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public myDoctorException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
}
