package com.example.demo.entity;
import java.time.LocalDate;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Entity
public class InPatient{
	public InPatient(Integer patientId2, String patientName2, Long patientNum2, Integer patientAge2, Gender gender2,
			List<PatientMedicine> patientMedicines2, String patientDoctor2, Integer patientRoomnum2, Object object) {
		// TODO Auto-generated constructor stub
	}
	@Id
	private Integer patientId;
	
	@Column
	@NotEmpty(message = "please provide patient name")
	private String patientName;
	
	@Column
	private Long patientNum;
	
	@Column
	
	private String patientAddress;
	
	@Column
	private Integer patientAge;
	
	@Column 
	@Enumerated(EnumType.STRING)
	public Gender gender;
	
	@Column 
	private Integer patientRoomnum;
	
	@OneToMany(targetEntity=PatientMedicine.class,cascade=CascadeType.ALL)
	@JoinColumn(name="pId_fk",referencedColumnName="patientId")
	private List<PatientMedicine> patientMedicines;
	
	@Column
	private String patientDoctor;
	@Column
	private LocalDate dicschargeDate;
	
	//getters and setters
	

	
}
