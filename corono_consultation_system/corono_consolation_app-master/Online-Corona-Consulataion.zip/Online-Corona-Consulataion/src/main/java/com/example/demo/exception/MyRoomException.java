package com.example.demo.exception;

public class MyRoomException  extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public MyRoomException() {
		super();
		
	}

	public MyRoomException(String message) {
		super(message);
		
	}
}
