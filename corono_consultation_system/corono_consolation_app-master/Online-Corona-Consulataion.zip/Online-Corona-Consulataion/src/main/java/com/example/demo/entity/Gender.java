package com.example.demo.entity;

public enum Gender {
	Male,
	Famale,
	Transgender,

}
