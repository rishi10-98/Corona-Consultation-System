package com.example.demo.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Doctor;
import com.example.demo.exception.DoctorNotFoundException;
import com.example.demo.service.IDoctorService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

// Doctor Controller To handle Rest Operation

@RestController
@RequestMapping(value = "/doctor")
@Api(description = "This is Doctor Controller to perform operations on Doctor")
@CrossOrigin(allowedHeaders = "*")
public class DoctorController {
	private static final Logger logger = LoggerFactory.getLogger(Doctor.class);
	@Autowired
	private IDoctorService doctorService;
	
	/* 
	 * http://localhost:8080/Doctor/saveDoctor
	 * this method saved the doctor object
	 * Http Post method Required
	 * */
	
	@PostMapping(value = "/saveDoctor")
	@ApiOperation(value  = "This is saveDoctor() method to save an Doctor  object in database table")
	public ResponseEntity<Doctor> saveDoctor(@Valid @RequestBody Doctor doctor) throws DoctorNotFoundException{
		logger.info("Trying to add Record  : " + doctor);
		try {
			Doctor savedDoctor= doctorService.addDoctor(doctor);
			
			return new ResponseEntity<Doctor>(savedDoctor, HttpStatus.CREATED);
			
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Record NOT Added  : " + doctor);
			return new ResponseEntity<Doctor>(new Doctor(), HttpStatus.EXPECTATION_FAILED);
		}
		
	}
	
	
	/* 
	 * http://localhost:8080/Doctor/allDoctor
	 * this method gets all  doctor record from database table
	 * Http get Method required
	 * */
	
	@GetMapping(value="/allDoctor")
	@ApiOperation(value  = "This is getaAllDoctor() method to get an all Doctor object from database table")
	public ResponseEntity<List<Doctor>> allDoctor() throws DoctorNotFoundException{		
		logger.info("Trying to fetch Doctor list ");
		try {
			List<Doctor> doctor = doctorService.getAllDoctor();

			if (doctor.isEmpty()) {
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			}
			return new ResponseEntity<>(doctor,HttpStatus.OK);
		} 
		catch (Exception e) {
			logger.error("Record NOT found : ");
			return new ResponseEntity<>( HttpStatus.INTERNAL_SERVER_ERROR);
		}
	
	}
	
	
	/* 
	 * http://localhost:8080/Doctor/docId
	 * this method get single record from table
	 * Http get Method required
	 * */
	
	
	@GetMapping(value="/{docId}")
	@ApiOperation(value  = "This is getDoctor() method to get an Doctor object From database table")
	public ResponseEntity<Doctor> getDoctorWithId(@PathVariable Long docId) throws DoctorNotFoundException{
	
	
	
			logger.info("Trying to search Record with Id : " + docId);
			Optional<Doctor> doctor = doctorService.getDoctorWithId(docId);			
				return new ResponseEntity<Doctor>(doctor.get(), HttpStatus.OK);
		
	}
	
	/* 
	 * http://localhost:8080/Doctor/docId
	 * this method update single record from table
	 * Http put method required
	 * */
	
	@PutMapping(value="/{docId}")
	@ApiOperation(value  = "This is getDoctorUpdate() method to Update object in database table")
	public ResponseEntity<Object> getDoctorupdate(@RequestBody Doctor doctor , @PathVariable Long docId ) throws DoctorNotFoundException{
		
		logger.info("trying to update Doctor : " +doctor);
		try {
				Optional<Doctor> doctorFound = doctorService.getDoctorWithId(docId);
				if (doctorFound.isPresent()) {
					logger.info("user found"+doctorFound);
					doctorService.getDoctorupdate(doctor, docId);					
					System.out.println("Record Updated : " + doctor);
					return ResponseEntity.ok(doctor);
				} else {
					return new ResponseEntity<>("Record NOT updated with Id : " + doctor,HttpStatus.NO_CONTENT);
							
		} 
		}catch (Exception e) {
			logger.error("Record NOT updated with Id : " + doctor);
			return new ResponseEntity<>("Record NOT updated with Id : " + doctor, HttpStatus.EXPECTATION_FAILED);
		}

	}
	/* 
	 * http://localhost:8080/Doctor/docId
	 * this method delete single record from table
	 * Http Delete method Required
	 * */
	
	@DeleteMapping("/{id}")
	@ApiOperation(value  = "This is deleteDoctor() method to Delete object in database table")
	public ResponseEntity<String> deleteDoctor(@PathVariable Long id) throws DoctorNotFoundException {
		logger.info("Record Deleted with Id : " + id);
		try {
			doctorService.deleteDoctor(id);
			
			return new ResponseEntity<>("Record Deleted...with id : "+id,HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Record NOT Deleted with Id : " + id);
			return new ResponseEntity<>("Record not found with id : "+id,HttpStatus.EXPECTATION_FAILED);
		}
	}
	
		
	
	@GetMapping(value="/doctorSearch/{name}")
	@ApiOperation(value  = "This is getaAllDoctor() method to get an all Doctor object from database table")
	public ResponseEntity<List<Doctor>> departmentSearch(@PathVariable String name) throws DoctorNotFoundException{		
		logger.info("Trying to fetch Doctor list ");
		try {
			List<Doctor> doctor = doctorService.getDoctorByName(name);

			if (doctor.isEmpty()) {
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			}
			return new ResponseEntity<>(doctor,HttpStatus.OK);
		} 
		catch (Exception e) {
			logger.error("Record NOT found : ");
			return new ResponseEntity<>( HttpStatus.INTERNAL_SERVER_ERROR);
		}
	
	}
	
	
	}
	

