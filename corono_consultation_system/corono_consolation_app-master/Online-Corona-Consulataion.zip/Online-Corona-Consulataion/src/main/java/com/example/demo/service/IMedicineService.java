package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import com.example.demo.entity.Medicine;
import com.example.demo.exception.MedicineNotFoundException;
import com.example.demo.exception.PatientNotFoundException;

public interface IMedicineService {
	
	
	public Optional<Medicine> getMedicineById(Integer mId) throws MedicineNotFoundException;
	public List<Medicine> getMedicineList()throws MedicineNotFoundException;
	public Medicine addMedicine(Medicine medicine) throws MedicineNotFoundException;

	public Medicine updateMedicine(Medicine mId)throws MedicineNotFoundException;
	public void deleteMedicine(Integer mId)throws MedicineNotFoundException;
	//public List<Medicine> getMedidcineByPatientId(Integer pId) throws PatientNotFoundException; 

}
