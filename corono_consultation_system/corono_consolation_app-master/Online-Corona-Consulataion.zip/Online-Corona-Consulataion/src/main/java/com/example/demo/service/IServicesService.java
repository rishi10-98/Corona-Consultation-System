package com.example.demo.service;

import com.example.demo.entity.Services;

//import com.google.common.base.Optional;

//import lombok.var;

public interface IServicesService {
	public Services saveServices(Services service1);
	// public Services getSingleService(Integer serviceId);
	// public void deleteServices(Long serviceId);

	Services getService(Integer serviceId);

	public void deleteService(Integer serviceId);

	public Services updateService(Integer serviceId, Services service);
	//public Integer getServiceId();

}
