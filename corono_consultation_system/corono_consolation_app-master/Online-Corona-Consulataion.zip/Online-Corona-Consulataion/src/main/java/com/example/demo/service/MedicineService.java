package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.repository.IMedicineDao;
import com.example.demo.repository.IPatientDao;
import com.example.demo.entity.Medicine;
import com.example.demo.exception.MedicineNotFoundException;

@Service
public class MedicineService implements IMedicineService{
	
	private static final Logger logger = LoggerFactory.getLogger(MedicineService.class);
	
	@Autowired
	private IMedicineDao medDao; 		//medicine repository object
	@Autowired
	private IPatientDao patDao;			//patient repository object
	
	//method to get single medicine using medicine id
	@Override
	public Optional<Medicine> getMedicineById(Integer mId) throws MedicineNotFoundException {
		logger.info("Trying to fetch Medicine from service Layer ");
				return medDao.findById(mId);
	}
	
	
	//method to get single all medicines
	@Override
	public List<Medicine> getMedicineList() throws MedicineNotFoundException {
		logger.info("Trying to fetch all Medicines from service Layer ");
		return medDao.findAll();
	}
	
	
	//method to add a single medicine
	@Override
	public Medicine addMedicine(Medicine medicine) throws MedicineNotFoundException {
		logger.info("Trying to add a Medicine in service layer "+ medicine);
		
	
		return medDao.save(medicine);
	}
	
	
	//method to update single medicine using medicine id
	@Override
	public Medicine updateMedicine(Medicine medicine) throws MedicineNotFoundException {
		logger.info("Trying to update a Medicine in service layer ");
		
		Integer mId = medicine.getMedId();
		Optional<Medicine> medicineFound = getMedicineById(mId);
		Medicine updatedMedicine = null;
		if (medicineFound.isPresent())
			updatedMedicine = medDao.save(medicine);
		
		return updatedMedicine;
	}
	
	//method to get delete medicine using medicine id
	@Override
	public void deleteMedicine(Integer mId) throws MedicineNotFoundException {
		logger.info("Trying to delete a Medicine in service layer ");
		 medDao.deleteById(mId);
	}

	
	/**method to get single all medicines of a patient using patient id 
	@Override
	public List<Medicine> getMedidcineByPatientId(Integer pId) throws PatientNotFoundException {
		logger.info("Trying to fetch list of medicines of a patient in service layer ");	  
		Patient p=patDao.findById(pId).orElseThrow(()->new PatientNotFoundException("Patient with given Id : "+pId+" dis not available"));
		//List<PatientMedicine> patientMedicines=p.getPatientMedicines();
			  
		//return medicines; 
	//}

*/	 
}
