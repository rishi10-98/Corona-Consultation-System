package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import com.example.demo.entity.ServiceReport;
import com.example.demo.exception.myServiceReportException;


public interface IServiceReportService {
	
	public ServiceReport addServiceReport(ServiceReport sreport) throws myServiceReportException;

	public List<ServiceReport> getAllServiceReport();
	
	public Optional<ServiceReport> getServiceReportById(Integer reportId) throws myServiceReportException;
	
	public void deleteServiceReportById(Integer reportId) throws myServiceReportException;
	
	public ServiceReport updateServiceReport(Integer reportId,ServiceReport sreport);
}
