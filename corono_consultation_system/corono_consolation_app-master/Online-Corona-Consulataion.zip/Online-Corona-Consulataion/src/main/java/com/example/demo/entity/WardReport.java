package com.example.demo.entity;

import javax.persistence.Embeddable;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Embeddable
@Data
@AllArgsConstructor
@NoArgsConstructor
public class WardReport {
	
	private Integer reportId;
	
	private Integer NumberOfRoom;
	
	private Integer availableBed;
	
	private float wardFee;
	
	@Enumerated(EnumType.STRING)
	private WardType wardType;

}
