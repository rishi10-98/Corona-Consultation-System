package com.example.demo.service;

import com.example.demo.exception.MedicineNotFoundException;

public interface IBillingService {

	public String generatePatientBill(Integer mId) throws MedicineNotFoundException;
}