package com.example.demo.exception;

public class MyInPatientException extends Exception{
	
	private static final long serialVersionUID = 1L;

	public MyInPatientException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public MyInPatientException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}

