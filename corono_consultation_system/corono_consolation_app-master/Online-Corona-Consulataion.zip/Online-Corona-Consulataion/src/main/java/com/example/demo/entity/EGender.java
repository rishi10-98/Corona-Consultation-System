package com.example.demo.entity;

public enum EGender {
    MALE,FEMALE
}
